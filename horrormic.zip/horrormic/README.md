# Horror Mic — mod de terror para Minecraft Java 1.20.4 (NeoForge)

Um mod de terror que **escuta o seu microfone**. Se você falar do **bicho** (ou "bixo"), ele aparece.

## O que ele faz

| Você diz | O que acontece |
|---|---|
| "ainda o bicho **não** vai aparecer" | O bicho aparece **na hora**, longe, nas suas costas, e te encara. Some se você olhar para ele por ~1,5 s ou depois de ~14 s. Como você negou, ele ainda volta **colado nas suas costas** por 2 s e some. |
| "se o bixo aparecer eu vou ficar **bravo**" | Aparece na hora e, quando você termina a frase, **aparece de novo** na sua frente e vem andando até você. |
| Qualquer outra frase com "bicho" | Aparece na hora (com intervalo mínimo de 6 s entre aparições). |

Sempre que você falar do bicho, isso acontece. As palavras ("bicho", "bixo", "bichinho", "bixinho") podem ser trocadas no arquivo de configuração.

### Microfone
- Detecta os microfones do seu computador e usa o padrão do sistema. Se houver mais de um, você escolhe no aviso.
- Fica **sempre ativo** enquanto você está no mundo. Se o microfone for desconectado, ele tenta reconectar sozinho a cada poucos segundos.
- Um indicador **MIC** no canto da tela mostra quando está ouvindo (vermelho = ouvindo, amarelo = carregando).

### Ao criar um mundo novo
Aparece uma tela de **aviso** explicando o mod e mostrando qual microfone foi detectado. O microfone **só liga depois que você aceita** ("Ativar microfone e jogar"). Existe também "Jogar sem microfone". A escolha fica salva no mundo (`horrormic.properties` dentro da pasta do mundo; apague esse arquivo para ver o aviso de novo). Mundos antigos mostram o aviso na primeira vez que são abertos.

### O que o mod NUNCA faz
- **Nunca fecha o jogo**: não existe nenhuma chamada de sair/crashar, e todo erro (microfone, modelo, internet, entidade) é capturado e só vai para o log.
- **Nunca tira o jogador do mundo**: não há desconexão nem teleporte para fora; a tela de aviso nem tem botão de sair.
- O bicho **não causa dano**, não pode ser ferido e nunca é salvo no mundo. O pior que ele faz é gritar e escurecer a tela por 1–2 segundos.

## Privacidade
O reconhecimento de voz usa o **Vosk**, que roda **offline no seu PC**. Nenhum áudio é gravado, salvo ou enviado. A única coisa baixada da internet é o modelo de voz em português (~31 MB, `vosk-model-small-pt-0.3`), uma única vez, de `alphacephei.com`.

> A "IA" aqui é o reconhecimento de voz (Vosk) mais regras simples que separam "só falou do bicho" / "negou" / "ficou bravo". Não é um modelo de linguagem como o ChatGPT.

## Como compilar

Precisa de **JDK 17** e internet (na primeira vez o Gradle baixa o NeoForge, o Minecraft e o Vosk).

```
./gradlew build          # Linux / Mac
gradlew.bat build        # Windows
```

O mod sai em `build/libs/horrormic-1.0.0.jar`. Para testar direto: `./gradlew runClient`.

## Como instalar
1. Instale o **NeoForge 1.20.4** (20.4.x) no Minecraft Java.
2. Coloque `horrormic-1.0.0.jar` na pasta `mods` do Minecraft.
3. Abra o jogo, crie um mundo, aceite o aviso e fale "bicho".
4. Se o Windows/Mac pedir permissão de microfone para o Java/Minecraft, aceite.

## Se o modelo de voz não baixar
Baixe `vosk-model-small-pt-0.3.zip` em https://alphacephei.com/vosk/models, extraia e coloque o conteúdo em `config/horrormic/vosk-model-pt/` (deve existir `config/horrormic/vosk-model-pt/am/final.mdl`).

## Configuração
`config/horrormic-client.toml`: ligar/desligar, lista de palavras, intervalo entre aparições e `showHeardText` (mostra na tela o que o microfone entendeu, ótimo para testar).

## Limitações
- Funciona em **mundos de um jogador**. Em servidor multiplayer o mod não escuta o microfone.
- O reconhecimento pode errar, principalmente com ruído ou microfone ruim. Se "bicho" não for entendido, ligue `showHeardText` e veja o que ele está ouvindo.
- Linux: o Java às vezes lista os microfones com nomes estranhos (`default [default]`, `plughw`). Troque no aviso se o primeiro não for o certo.

package com.horrormic;

import java.util.ArrayList;
import java.util.List;
import net.neoforged.neoforge.common.ModConfigSpec;

/** Configuracao do cliente: config/horrormic-client.toml */
public final class HorrorMicConfig {
    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    public static final ModConfigSpec.BooleanValue ENABLED = BUILDER
            .comment("Liga/desliga o reconhecimento de voz.")
            .define("enabled", true);

    public static final ModConfigSpec.ConfigValue<List<? extends String>> KEYWORDS = BUILDER
            .comment("Palavras que fazem o bicho aparecer (sem acento, minusculas).")
            .defineListAllowEmpty("keywords",
                    List.of("bicho", "bixo", "bichinho", "bixinho"),
                    o -> o instanceof String);

    public static final ModConfigSpec.IntValue COOLDOWN_SECONDS = BUILDER
            .comment("Tempo minimo entre duas aparicoes imediatas, em segundos.")
            .defineInRange("cooldownSeconds", 6, 1, 120);

    public static final ModConfigSpec.BooleanValue SHOW_HEARD = BUILDER
            .comment("Mostra na tela o ultimo texto que o microfone entendeu (util para testar).")
            .define("showHeardText", false);

    public static final ModConfigSpec.IntValue VOLUME_THRESHOLD = BUILDER
            .comment("Modo volume (usado quando o reconhecimento de voz nao carrega): volume minimo, de 100 a 20000, "
                    + "para o bicho aparecer. Menor = mais sensivel.")
            .defineInRange("volumeThreshold", 2500, 100, 20000);

    public static final ModConfigSpec SPEC = BUILDER.build();

    private HorrorMicConfig() {}

    // Os getters abaixo nunca lancam excecao: se a config ainda nao carregou, usam o padrao.

    public static boolean enabled() {
        try { return ENABLED.get(); } catch (Throwable t) { return true; }
    }

    public static List<String> keywords() {
        try {
            return new ArrayList<>(KEYWORDS.get());
        } catch (Throwable t) {
            return List.of("bicho", "bixo", "bichinho", "bixinho");
        }
    }

    public static int volumeThreshold() {
        try { return VOLUME_THRESHOLD.get(); } catch (Throwable t) { return 2500; }
    }

    public static int cooldownSeconds() {
        try { return COOLDOWN_SECONDS.get(); } catch (Throwable t) { return 6; }
    }

    public static boolean showHeard() {
        try { return SHOW_HEARD.get(); } catch (Throwable t) { return false; }
    }
}

package com.horrormic.client.audio;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.horrormic.HorrorMicMod;
import com.horrormic.client.audio.MicrophoneManager.Mic;
import java.util.Arrays;
import java.util.function.Consumer;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;
import org.vosk.Model;
import org.vosk.Recognizer;

/**
 * Fica ouvindo o microfone numa thread propria, o tempo todo, e manda o texto reconhecido
 * para quem estiver interessado. Se o microfone falhar, tenta de novo a cada poucos segundos.
 * Nenhuma falha aqui sai da thread: o jogo nunca e afetado.
 */
public final class VoiceListener implements Runnable {

    /** Texto reconhecido. isFinal = frase terminada; false = parcial (ainda falando). */
    public record Heard(String text, boolean isFinal) {}

    private final Mic mic;
    private final Model model;
    private final Consumer<Heard> onHeard;
    private final Consumer<String> onProblem;

    private volatile boolean running;
    private volatile TargetDataLine line;
    private Thread thread;

    public VoiceListener(Mic mic, Model model, Consumer<Heard> onHeard, Consumer<String> onProblem) {
        this.mic = mic;
        this.model = model;
        this.onHeard = onHeard;
        this.onProblem = onProblem;
    }

    public void start() {
        running = true;
        thread = new Thread(this, "HorrorMic-Listener");
        thread.setDaemon(true);
        thread.start();
    }

    public void stop() {
        running = false;
        TargetDataLine l = line;
        if (l != null) {
            try {
                l.stop();
                l.close();
            } catch (Throwable ignored) {
                // nada a fazer
            }
        }
        Thread t = thread;
        if (t != null) {
            t.interrupt();
        }
    }

    @Override
    public void run() {
        boolean reported = false;
        while (running) {
            try {
                listenOnce();
                if (running) {
                    sleep(2000); // a linha foi fechada (microfone sumiu?): espera e reabre
                }
            } catch (Throwable t) {
                if (!running) {
                    break;
                }
                HorrorMicMod.LOGGER.warn("Horror Mic: erro no microfone, tentando de novo em 5 s.", t);
                if (!reported) {
                    reported = true;
                    try {
                        onProblem.accept(String.valueOf(t.getMessage()));
                    } catch (Throwable ignored) {
                        // nada a fazer
                    }
                }
                sleep(5000);
            }
        }
    }

    private void listenOnce() throws Exception {
        AudioFormat fmt = MicrophoneManager.format(mic.rate());
        Mixer mixer = AudioSystem.getMixer(mic.info());
        TargetDataLine l = (TargetDataLine) mixer.getLine(new DataLine.Info(TargetDataLine.class, fmt));
        l.open(fmt);
        l.start();
        line = l;

        byte[] buf = new byte[(mic.rate() / 8) * 2]; // blocos de 125 ms
        try (Recognizer rec = new Recognizer(model, (float) MicrophoneManager.TARGET_RATE)) {
            while (running) {
                int n = l.read(buf, 0, buf.length);
                if (n <= 0) {
                    if (!l.isOpen()) {
                        break;
                    }
                    continue;
                }
                byte[] pcm;
                if (mic.rate() == MicrophoneManager.TARGET_RATE) {
                    pcm = (n == buf.length) ? buf : Arrays.copyOf(buf, n);
                } else {
                    pcm = Resampler.to16k(buf, n, mic.rate());
                }

                boolean fin = rec.acceptWaveForm(pcm, pcm.length);
                String text = extract(fin ? rec.getResult() : rec.getPartialResult(), fin);
                if (text != null && (fin || !text.isEmpty())) {
                    onHeard.accept(new Heard(text, fin));
                }
            }
        } finally {
            try {
                l.stop();
                l.close();
            } catch (Throwable ignored) {
                // nada a fazer
            }
            line = null;
        }
    }

    private static String extract(String json, boolean fin) {
        try {
            JsonObject o = JsonParser.parseString(json).getAsJsonObject();
            String key = fin ? "text" : "partial";
            return o.has(key) ? o.get(key).getAsString().trim() : null;
        } catch (Throwable t) {
            return null;
        }
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
            // stop() interrompe a thread de proposito
        }
    }
}

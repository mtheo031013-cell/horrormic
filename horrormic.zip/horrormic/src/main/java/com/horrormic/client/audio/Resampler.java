package com.horrormic.client.audio;

/** Converte audio PCM 16 bits mono little-endian de qualquer taxa para 16 kHz (media por janela). */
final class Resampler {
    private Resampler() {}

    static byte[] to16k(byte[] in, int len, int rate) {
        int samplesIn = len / 2;
        int samplesOut = (int) ((long) samplesIn * MicrophoneManager.TARGET_RATE / rate);
        byte[] out = new byte[samplesOut * 2];
        double step = (double) rate / MicrophoneManager.TARGET_RATE;

        for (int i = 0; i < samplesOut; i++) {
            int from = (int) (i * step);
            int to = Math.min(samplesIn, Math.max(from + 1, (int) ((i + 1) * step)));
            long sum = 0;
            for (int j = from; j < to; j++) {
                sum += sample(in, j);
            }
            short s = (short) (sum / Math.max(1, to - from));
            out[2 * i] = (byte) (s & 0xFF);
            out[2 * i + 1] = (byte) ((s >> 8) & 0xFF);
        }
        return out;
    }

    private static short sample(byte[] b, int index) {
        return (short) ((b[2 * index] & 0xFF) | (b[2 * index + 1] << 8));
    }
}

package com.horrormic.client.audio;

import com.horrormic.HorrorMicMod;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.Comparator;
import java.util.function.Consumer;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import net.neoforged.fml.loading.FMLPaths;

/**
 * Garante que o modelo de voz em portugues esta em config/horrormic/vosk-model-pt.
 * Se nao estiver, baixa uma vez (~31 MB). Voce tambem pode colocar o modelo la manualmente.
 */
public final class ModelManager {
    private static final String MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip";

    private ModelManager() {}

    public static Path modelDir() {
        return FMLPaths.CONFIGDIR.get().resolve("horrormic").resolve("vosk-model-pt");
    }

    private static boolean isReady(Path dir) {
        return Files.isRegularFile(dir.resolve("am").resolve("final.mdl"));
    }

    public static Path ensureModel(Consumer<String> status) throws IOException, InterruptedException {
        Path dir = modelDir();
        if (isReady(dir)) {
            return dir;
        }

        Path base = dir.getParent();
        Files.createDirectories(base);
        Path zip = base.resolve("modelo-pt.zip.tmp");
        Path tmpDir = base.resolve("vosk-model-pt.tmp");

        try {
            status.accept("Horror Mic: baixando modelo de voz (so na primeira vez)...");
            download(zip, status);

            status.accept("Horror Mic: instalando modelo de voz...");
            deleteRecursively(tmpDir);
            unzip(zip, tmpDir);

            deleteRecursively(dir);
            Files.move(tmpDir, dir, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(zip);
            deleteRecursively(tmpDir);
        }

        if (!isReady(dir)) {
            throw new IOException("Modelo baixado esta incompleto.");
        }
        return dir;
    }

    private static void download(Path zip, Consumer<String> status) throws IOException, InterruptedException {
        HttpClient client = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .connectTimeout(Duration.ofSeconds(20))
                .build();
        HttpRequest req = HttpRequest.newBuilder(URI.create(MODEL_URL))
                .timeout(Duration.ofMinutes(10))
                .GET()
                .build();
        HttpResponse<InputStream> resp = client.send(req, HttpResponse.BodyHandlers.ofInputStream());
        if (resp.statusCode() != 200) {
            throw new IOException("Download falhou (HTTP " + resp.statusCode() + ")");
        }

        long total = resp.headers().firstValueAsLong("Content-Length").orElse(-1L);
        long read = 0;
        int lastPct = -1;
        try (InputStream in = resp.body(); OutputStream out = Files.newOutputStream(zip)) {
            byte[] chunk = new byte[64 * 1024];
            int n;
            while ((n = in.read(chunk)) > 0) {
                out.write(chunk, 0, n);
                read += n;
                if (total > 0) {
                    int pct = (int) (read * 100 / total);
                    if (pct / 10 != lastPct / 10) {
                        lastPct = pct;
                        status.accept("Horror Mic: baixando modelo de voz... " + pct + "%");
                    }
                }
            }
        }
    }

    private static void unzip(Path zip, Path target) throws IOException {
        Files.createDirectories(target);
        Path root = target.toAbsolutePath().normalize();
        try (ZipInputStream zin = new ZipInputStream(Files.newInputStream(zip))) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName();
                int slash = name.indexOf('/');
                String rel = slash >= 0 ? name.substring(slash + 1) : name; // tira a pasta raiz do zip
                if (rel.isEmpty()) {
                    continue;
                }
                Path out = root.resolve(rel).normalize();
                if (!out.startsWith(root)) {
                    throw new IOException("Entrada de zip invalida: " + name);
                }
                if (e.isDirectory()) {
                    Files.createDirectories(out);
                } else {
                    Files.createDirectories(out.getParent());
                    Files.copy(zin, out, StandardCopyOption.REPLACE_EXISTING);
                }
            }
        }
    }

    private static void deleteRecursively(Path p) {
        if (!Files.exists(p)) {
            return;
        }
        try (Stream<Path> walk = Files.walk(p)) {
            walk.sorted(Comparator.reverseOrder()).forEach(x -> {
                try {
                    Files.deleteIfExists(x);
                } catch (IOException ex) {
                    HorrorMicMod.LOGGER.debug("Nao consegui apagar {}", x);
                }
            });
        } catch (IOException ex) {
            HorrorMicMod.LOGGER.debug("Nao consegui limpar {}", p);
        }
    }
}

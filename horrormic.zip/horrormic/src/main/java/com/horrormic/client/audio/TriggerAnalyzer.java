package com.horrormic.client.audio;

import java.text.Normalizer;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Entende a frase. Nao e um LLM: e o reconhecimento de voz (Vosk, IA offline) somado a regras
 * simples que separam "so falou do bicho" de "negou o bicho" e de "desafiou/ficou bravo".
 */
public final class TriggerAnalyzer {

    public enum Intent {
        /** So mencionou o bicho. */
        MENTION,
        /** Negou: "o bicho nao vai aparecer", "nunca", "mentira"... */
        DENIAL,
        /** Desafiou ou ficou bravo: "se o bicho aparecer vou ficar bravo", "cade o bicho"... */
        ANGER
    }

    private static final Set<String> DENIAL_WORDS = Set.of(
            "nao", "n", "nunca", "jamais", "nem", "duvido", "mentira", "falso",
            "besteira", "bobagem", "imagina");

    private static final Set<String> ANGER_WORDS = Set.of(
            "bravo", "brava", "raiva", "furioso", "furiosa", "irritado", "irritada",
            "nervoso", "nervosa", "odeio", "venha", "vem", "cade");

    private TriggerAnalyzer() {}

    public static String normalize(String s) {
        String lower = s.toLowerCase(Locale.ROOT);
        return Normalizer.normalize(lower, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
    }

    private static List<String> tokens(String text) {
        return Arrays.stream(normalize(text).split("[^a-z0-9]+"))
                .filter(w -> !w.isEmpty())
                .collect(Collectors.toList());
    }

    /** Quantas vezes o bicho foi citado no texto. */
    public static int countMentions(String text, List<String> keywords) {
        List<String> kws = keywords.stream().map(TriggerAnalyzer::normalize).collect(Collectors.toList());
        int count = 0;
        for (String word : tokens(text)) {
            for (String kw : kws) {
                if (!kw.isEmpty() && word.startsWith(kw)) {
                    count++;
                    break;
                }
            }
        }
        return count;
    }

    /** Classifica a frase inteira (usar com o resultado final do reconhecimento). */
    public static Intent classify(String text) {
        List<String> toks = tokens(text);
        String joined = " " + String.join(" ", toks) + " ";

        boolean anger = toks.stream().anyMatch(ANGER_WORDS::contains)
                || joined.contains(" vou ficar ")
                || joined.contains(" quero ver ")
                || joined.contains(" de novo ")
                || joined.contains(" denovo ")
                || (toks.contains("se") && toks.stream().anyMatch(w -> w.startsWith("aparec")));
        if (anger) {
            return Intent.ANGER;
        }

        boolean denial = toks.stream().anyMatch(DENIAL_WORDS::contains);
        return denial ? Intent.DENIAL : Intent.MENTION;
    }
}

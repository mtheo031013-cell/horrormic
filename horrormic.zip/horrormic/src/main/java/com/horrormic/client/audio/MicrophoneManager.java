package com.horrormic.client.audio;

import com.horrormic.HorrorMicMod;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;

/** Descobre quais microfones o sistema tem. */
public final class MicrophoneManager {
    /** Taxa de amostragem que o modelo de voz espera. */
    public static final int TARGET_RATE = 16000;
    private static final int[] RATES = {16000, 44100, 48000, 22050, 32000};

    public record Mic(String name, Mixer.Info info, int rate) {}

    private MicrophoneManager() {}

    public static AudioFormat format(int rate) {
        // PCM 16 bits, mono, little-endian
        return new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, rate, 16, 1, 2, rate, false);
    }

    /** Lista os microfones capazes de gravar. O primeiro costuma ser o padrao do sistema. */
    public static List<Mic> detect() {
        List<Mic> result = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        try {
            for (Mixer.Info info : AudioSystem.getMixerInfo()) {
                String name = info.getName();
                if (name == null || name.startsWith("Port ") || !seen.add(name)) {
                    continue;
                }
                try {
                    Mixer mixer = AudioSystem.getMixer(info);
                    for (int rate : RATES) {
                        DataLine.Info lineInfo = new DataLine.Info(TargetDataLine.class, format(rate));
                        if (mixer.isLineSupported(lineInfo)) {
                            result.add(new Mic(name, info, rate));
                            break;
                        }
                    }
                } catch (Throwable ignored) {
                    // dispositivo problematico: pula
                }
            }
        } catch (Throwable t) {
            HorrorMicMod.LOGGER.warn("Horror Mic: nao consegui listar os microfones.", t);
        }
        return result;
    }

    /** Escolhe o microfone preferido pelo nome; se nao achar, o primeiro da lista. */
    public static Mic choose(List<Mic> mics, String preferredName) {
        if (mics.isEmpty()) {
            return null;
        }
        if (preferredName != null && !preferredName.isBlank()) {
            for (Mic m : mics) {
                if (m.name().equalsIgnoreCase(preferredName)) {
                    return m;
                }
            }
        }
        return mics.get(0);
    }
}

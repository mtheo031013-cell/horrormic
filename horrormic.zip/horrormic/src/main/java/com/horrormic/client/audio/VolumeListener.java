package com.horrormic.client.audio;

import com.horrormic.HorrorMicConfig;
import com.horrormic.HorrorMicMod;
import com.horrormic.client.audio.MicrophoneManager.Mic;
import com.horrormic.client.audio.VoiceListener.Heard;
import java.util.function.Consumer;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;

/**
 * Plano B, sem modelo de voz e sem Vosk: so mede o volume do microfone.
 * Se voce falar ou gritar alto, o bicho aparece. Nao importa o que voce diga.
 * Esta classe nao usa nada do Vosk, entao funciona mesmo que ele nao carregue (ex.: Android).
 */
public final class VolumeListener implements Runnable {
    private final Mic mic;
    private final Consumer<Heard> onHeard;
    private final Consumer<String> onProblem;

    private volatile boolean running;
    private volatile TargetDataLine line;
    private Thread thread;

    public VolumeListener(Mic mic, Consumer<Heard> onHeard, Consumer<String> onProblem) {
        this.mic = mic;
        this.onHeard = onHeard;
        this.onProblem = onProblem;
    }

    public void start() {
        running = true;
        thread = new Thread(this, "HorrorMic-Volume");
        thread.setDaemon(true);
        thread.start();
    }

    public void stop() {
        running = false;
        TargetDataLine l = line;
        if (l != null) {
            try {
                l.stop();
                l.close();
            } catch (Throwable ignored) {
                // nada a fazer
            }
        }
        Thread t = thread;
        if (t != null) {
            t.interrupt();
        }
    }

    @Override
    public void run() {
        boolean reported = false;
        while (running) {
            try {
                listenOnce();
                if (running) {
                    sleep(2000);
                }
            } catch (Throwable t) {
                if (!running) {
                    break;
                }
                HorrorMicMod.LOGGER.warn("Horror Mic: erro no microfone (modo volume), tentando de novo.", t);
                if (!reported) {
                    reported = true;
                    try {
                        onProblem.accept(String.valueOf(t.getMessage()));
                    } catch (Throwable ignored) {
                        // nada a fazer
                    }
                }
                sleep(5000);
            }
        }
    }

    private void listenOnce() throws Exception {
        AudioFormat fmt = MicrophoneManager.format(mic.rate());
        Mixer mixer = AudioSystem.getMixer(mic.info());
        TargetDataLine l = (TargetDataLine) mixer.getLine(new DataLine.Info(TargetDataLine.class, fmt));
        l.open(fmt);
        l.start();
        line = l;

        byte[] buf = new byte[(mic.rate() / 10) * 2]; // blocos de 100 ms
        long lastFire = 0;
        try {
            while (running) {
                int n = l.read(buf, 0, buf.length);
                if (n <= 0) {
                    if (!l.isOpen()) {
                        break;
                    }
                    continue;
                }
                if (rms(buf, n) >= HorrorMicConfig.volumeThreshold()) {
                    long now = System.currentTimeMillis();
                    if (now - lastFire > 1500) { // o intervalo de verdade e controlado pelo mod
                        lastFire = now;
                        onHeard.accept(new Heard("bicho", true));
                    }
                }
            }
        } finally {
            try {
                l.stop();
                l.close();
            } catch (Throwable ignored) {
                // nada a fazer
            }
            line = null;
        }
    }

    /** Volume medio (0 a 32767) de um bloco de audio PCM 16 bits. */
    private static double rms(byte[] b, int len) {
        int samples = len / 2;
        if (samples == 0) {
            return 0;
        }
        double sum = 0;
        for (int i = 0; i < samples; i++) {
            short s = (short) ((b[2 * i] & 0xFF) | (b[2 * i + 1] << 8));
            sum += (double) s * s;
        }
        return Math.sqrt(sum / samples);
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
            // stop() interrompe a thread de proposito
        }
    }
}

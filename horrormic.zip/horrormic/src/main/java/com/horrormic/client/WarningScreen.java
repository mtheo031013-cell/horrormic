package com.horrormic.client;

import com.horrormic.client.audio.MicrophoneManager.Mic;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

/**
 * Aviso mostrado ao criar um mundo novo. Mostra qual microfone foi detectado e so liga o
 * microfone se o jogador aceitar. Nao existe botao de sair do mundo: so "ativar" ou "jogar sem".
 */
public class WarningScreen extends Screen {
    private final List<Mic> mics;
    private final BiConsumer<Boolean, Mic> onChoice;
    private int micIndex;
    private Button micButton;

    private List<FormattedCharSequence> body = new ArrayList<>();
    private int bodyWidth;

    public WarningScreen(List<Mic> mics, BiConsumer<Boolean, Mic> onChoice) {
        super(Component.literal("AVISO - Horror Mic"));
        this.mics = mics;
        this.onChoice = onChoice;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height - 28;

        addRenderableWidget(Button.builder(Component.literal("Jogar sem microfone"), b -> finish(false))
                .bounds(cx - 100, y, 200, 20).build());
        y -= 24;

        Button accept = Button.builder(Component.literal("Ativar microfone e jogar"), b -> finish(true))
                .bounds(cx - 100, y, 200, 20).build();
        accept.active = !mics.isEmpty();
        addRenderableWidget(accept);
        y -= 24;

        if (mics.size() > 1) {
            micButton = Button.builder(micLabel(), b -> {
                micIndex = (micIndex + 1) % mics.size();
                b.setMessage(micLabel());
            }).bounds(cx - 130, y, 260, 20).build();
            addRenderableWidget(micButton);
        }

        bodyWidth = Math.min(this.width - 40, 340);
        body = new ArrayList<>();
        addParagraph("Este mod usa o seu microfone o tempo todo enquanto voce estiver neste mundo.");
        addParagraph("Se voce falar do bicho... ele escuta. E aparece.");
        addParagraph("A voz e reconhecida aqui no seu PC (modelo offline). Nenhum audio e gravado nem enviado. "
                + "Na primeira vez, um modelo de voz de ~31 MB e baixado.");
        addParagraph(mics.isEmpty()
                ? "Microfone detectado: NENHUM. Conecte um microfone para ativar."
                : "Microfone detectado: " + mics.get(micIndex).name());
    }

    private void addParagraph(String text) {
        body.addAll(this.font.split(Component.literal(text), bodyWidth));
        body.add(FormattedCharSequence.EMPTY);
    }

    private Component micLabel() {
        return Component.literal("Microfone: " + mics.get(micIndex).name() + " (clique para trocar)");
    }

    private void finish(boolean enabled) {
        Mic selected = mics.isEmpty() ? null : mics.get(micIndex);
        onChoice.accept(enabled, selected);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick); // fundo + botoes
        g.drawCenteredString(this.font, this.title, this.width / 2, 16, 0xFF5555);

        int x = (this.width - bodyWidth) / 2;
        int y = 38;
        for (FormattedCharSequence line : body) {
            g.drawString(this.font, line, x, y, 0xE0E0E0);
            y += 10;
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false; // tem que escolher; nao ha saida do mundo por aqui
    }
}

package com.horrormic.client;

import com.horrormic.HorrorMicMod;
import com.horrormic.entity.BichoEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Desenha o bicho com o modelo humanoide e uma textura propria (preta, olhos brancos). */
public class BichoRenderer extends MobRenderer<BichoEntity, HumanoidModel<BichoEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(HorrorMicMod.MODID, "textures/entity/bicho.png");

    public BichoRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE)), 0.4F);
    }

    @Override
    public ResourceLocation getTextureLocation(BichoEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(BichoEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.05F, 1.2F, 1.05F); // mais alto e magro que um jogador
    }
}

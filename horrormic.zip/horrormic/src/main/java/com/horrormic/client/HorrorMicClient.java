package com.horrormic.client;

import com.horrormic.HorrorMicConfig;
import com.horrormic.HorrorMicMod;
import com.horrormic.Reaction;
import com.horrormic.client.audio.MicrophoneManager;
import com.horrormic.client.audio.MicrophoneManager.Mic;
import com.horrormic.client.audio.ModelManager;
import com.horrormic.client.audio.TriggerAnalyzer;
import com.horrormic.client.audio.TriggerAnalyzer.Intent;
import com.horrormic.client.audio.VoiceListener;
import com.horrormic.client.audio.VoiceListener.Heard;
import com.horrormic.entity.BichoSpawner;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;
import org.vosk.Model;

/**
 * Cerebro do lado do cliente: liga/desliga o microfone, decide quando o bicho aparece
 * e mostra o aviso. Funciona em mundos de um jogador (servidor integrado).
 *
 * Regra de ouro: nada aqui fecha o jogo ou tira o jogador do mundo. Todo caminho de erro
 * so registra no log e segue em frente.
 */
public final class HorrorMicClient {

    public enum State { OFF, LOADING, LISTENING, ERROR }

    public static volatile State state = State.OFF;
    public static volatile String micName = "";
    public static volatile String lastHeard = "";

    private static volatile VoiceListener listener;
    private static volatile Model model; // fica em cache entre mundos
    private static volatile int generation;

    private static boolean pendingWarning;
    private static long clientTicks;
    private static long lastTriggerTick = -100000L;
    private static int seenMentions; // so a thread do microfone mexe nisto

    private record Delayed(long atTick, Reaction reaction) {}

    private static final List<Delayed> DELAYED = new ArrayList<>();

    private HorrorMicClient() {}

    // ------------------------------------------------------------------ entrada / saida do mundo

    public static void onLogin() {
        try {
            Minecraft mc = Minecraft.getInstance();
            MinecraftServer server = mc.getSingleplayerServer();
            if (server == null) {
                state = State.OFF; // multiplayer: o mod nao escuta
                return;
            }
            Properties ack = readAck(server);
            if (ack == null) {
                pendingWarning = true; // mundo novo (ou primeira vez): mostra o aviso
            } else if (Boolean.parseBoolean(ack.getProperty("enabled", "false"))) {
                startListening(ack.getProperty("mic", ""));
            }
        } catch (Throwable t) {
            HorrorMicMod.LOGGER.error("Horror Mic: falha ao entrar no mundo (ignorada).", t);
        }
    }

    public static void onLogout() {
        try {
            pendingWarning = false;
            DELAYED.clear();
            stop();
        } catch (Throwable t) {
            HorrorMicMod.LOGGER.error("Horror Mic: falha ao sair do mundo (ignorada).", t);
        }
    }

    // ------------------------------------------------------------------ tick (thread principal)

    public static void tick() {
        clientTicks++;
        Minecraft mc = Minecraft.getInstance();

        if (pendingWarning && mc.player != null && mc.level != null
                && mc.screen == null && mc.getSingleplayerServer() != null) {
            pendingWarning = false;
            mc.setScreen(new WarningScreen(MicrophoneManager.detect(), HorrorMicClient::onWarningChoice));
        }

        Iterator<Delayed> it = DELAYED.iterator();
        while (it.hasNext()) {
            Delayed d = it.next();
            if (clientTicks >= d.atTick()) {
                it.remove();
                requestReaction(d.reaction());
            }
        }
    }

    // ------------------------------------------------------------------ aviso

    private static void onWarningChoice(boolean enabled, Mic mic) {
        try {
            Minecraft mc = Minecraft.getInstance();
            MinecraftServer server = mc.getSingleplayerServer();
            if (server != null) {
                writeAck(server, enabled, mic == null ? "" : mic.name());
            }
            mc.setScreen(null);
            if (enabled) {
                startListening(mic == null ? "" : mic.name());
            }
        } catch (Throwable t) {
            HorrorMicMod.LOGGER.error("Horror Mic: falha ao confirmar o aviso (ignorada).", t);
            Minecraft.getInstance().setScreen(null);
        }
    }

    private static Path ackPath(MinecraftServer server) {
        return server.getWorldPath(LevelResource.ROOT).resolve("horrormic.properties");
    }

    private static Properties readAck(MinecraftServer server) {
        Path p = ackPath(server);
        if (!Files.isRegularFile(p)) {
            return null;
        }
        try (var in = Files.newInputStream(p)) {
            Properties props = new Properties();
            props.load(in);
            return props;
        } catch (IOException e) {
            HorrorMicMod.LOGGER.warn("Horror Mic: nao consegui ler {}", p, e);
            return null;
        }
    }

    private static void writeAck(MinecraftServer server, boolean enabled, String mic) {
        Properties props = new Properties();
        props.setProperty("enabled", Boolean.toString(enabled));
        props.setProperty("mic", mic);
        try (var out = Files.newOutputStream(ackPath(server))) {
            props.store(out, "Horror Mic - escolha feita no aviso deste mundo. Apague este arquivo para ver o aviso de novo.");
        } catch (IOException e) {
            HorrorMicMod.LOGGER.warn("Horror Mic: nao consegui salvar a escolha do aviso.", e);
        }
    }

    // ------------------------------------------------------------------ microfone

    public static void startListening(String preferredMic) {
        stop();
        if (!HorrorMicConfig.enabled()) {
            return;
        }
        final int gen = ++generation;
        state = State.LOADING;
        Thread t = new Thread(() -> bootstrap(preferredMic, gen), "HorrorMic-Bootstrap");
        t.setDaemon(true);
        t.start();
    }

    private static void bootstrap(String preferredMic, int gen) {
        try {
            Mic mic = MicrophoneManager.choose(MicrophoneManager.detect(), preferredMic);
            if (mic == null) {
                fail("Horror Mic: nenhum microfone encontrado. O jogo continua normalmente.");
                return;
            }
            micName = mic.name();

            Model m = model;
            if (m == null) {
                Path dir = ModelManager.ensureModel(HorrorMicClient::say);
                m = new Model(dir.toString());
                model = m;
            }

            if (gen != generation) {
                return; // o jogador saiu do mundo enquanto carregava
            }
            VoiceListener l = new VoiceListener(mic, m, HorrorMicClient::handleHeard, HorrorMicClient::onMicProblem);
            listener = l;
            l.start();
            state = State.LISTENING;
            say("Horror Mic: microfone ativo (" + mic.name() + ")");
        } catch (Throwable t) {
            HorrorMicMod.LOGGER.error("Horror Mic: nao consegui iniciar o reconhecimento de voz.", t);
            fail("Horror Mic: sem reconhecimento de voz (" + t.getMessage() + "). "
                    + "O jogo continua normalmente. Veja o README para instalar o modelo manualmente.");
        }
    }

    public static void stop() {
        generation++;
        VoiceListener l = listener;
        listener = null;
        if (l != null) {
            l.stop();
        }
        state = State.OFF;
        lastHeard = "";
        seenMentions = 0;
    }

    private static void onMicProblem(String msg) {
        state = State.ERROR;
        say("Horror Mic: problema com o microfone (" + msg + "). Vou tentar de novo sozinho.");
    }

    private static void fail(String msg) {
        state = State.ERROR;
        sayChat(msg);
    }

    // ------------------------------------------------------------------ o que foi ouvido (thread do microfone)

    private static void handleHeard(Heard h) {
        try {
            String text = h.text();
            if (!text.isEmpty()) {
                lastHeard = text;
            }

            int mentions = TriggerAnalyzer.countMentions(text, HorrorMicConfig.keywords());
            boolean fresh = mentions > seenMentions;
            if (fresh) {
                seenMentions = mentions;
            }
            boolean mentionedInUtterance = seenMentions > 0;

            Intent intent = (h.isFinal() && mentionedInUtterance)
                    ? TriggerAnalyzer.classify(text)
                    : Intent.MENTION;
            if (h.isFinal()) {
                seenMentions = 0;
            }

            if (!fresh && intent == Intent.MENTION) {
                return;
            }
            Minecraft.getInstance().execute(() -> react(fresh, intent));
        } catch (Throwable t) {
            HorrorMicMod.LOGGER.error("Horror Mic: falha ao analisar a fala (ignorada).", t);
        }
    }

    /** Roda na thread principal. */
    private static void react(boolean fresh, Intent intent) {
        try {
            // 1) Falou do bicho: ele aparece na hora (parecido com "aparece e depois some").
            long cooldown = HorrorMicConfig.cooldownSeconds() * 20L;
            if (fresh && clientTicks - lastTriggerTick >= cooldown) {
                lastTriggerTick = clientTicks;
                requestReaction(Reaction.PEEK);
            }
            // 2) A frase terminou: se negou ou desafiou, ele reage de novo, um instante depois.
            if (intent == Intent.DENIAL) {
                DELAYED.add(new Delayed(clientTicks + 30, Reaction.BEHIND));
            } else if (intent == Intent.ANGER) {
                DELAYED.add(new Delayed(clientTicks + 24, Reaction.AGAIN));
            }
        } catch (Throwable t) {
            HorrorMicMod.LOGGER.error("Horror Mic: falha ao reagir (ignorada).", t);
        }
    }

    /** Pede ao servidor integrado para invocar o bicho perto do jogador. */
    private static void requestReaction(Reaction reaction) {
        Minecraft mc = Minecraft.getInstance();
        MinecraftServer server = mc.getSingleplayerServer();
        if (server == null || mc.player == null) {
            return;
        }
        UUID id = mc.player.getUUID();
        server.execute(() -> {
            try {
                ServerPlayer sp = server.getPlayerList().getPlayer(id);
                if (sp != null) {
                    BichoSpawner.trigger(sp, reaction);
                }
            } catch (Throwable t) {
                HorrorMicMod.LOGGER.error("Horror Mic: falha ao invocar o bicho (ignorada).", t);
            }
        });
    }

    // ------------------------------------------------------------------ mensagens

    private static void say(String msg) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            if (mc.player != null) {
                mc.player.displayClientMessage(Component.literal(msg), true);
            }
        });
    }

    private static void sayChat(String msg) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            if (mc.player != null) {
                mc.player.displayClientMessage(Component.literal(msg), false);
            }
        });
    }
}

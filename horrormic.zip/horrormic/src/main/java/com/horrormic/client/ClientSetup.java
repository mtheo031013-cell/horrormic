package com.horrormic.client;

import com.horrormic.HorrorMicConfig;
import com.horrormic.HorrorMicMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModLoadingContext;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.TickEvent;

/** Liga tudo que e so de cliente. Esta classe so e carregada quando o jogo roda como cliente. */
public final class ClientSetup {
    private ClientSetup() {}

    public static void init(IEventBus modBus) {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, HorrorMicConfig.SPEC);

        modBus.addListener(ClientSetup::registerRenderers);

        NeoForge.EVENT_BUS.addListener(ClientSetup::onLoggingIn);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onLoggingOut);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onClientTick);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onRenderGui);
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(HorrorMicMod.BICHO.get(), BichoRenderer::new);
    }

    private static void onLoggingIn(ClientPlayerNetworkEvent.LoggingIn event) {
        HorrorMicClient.onLogin();
    }

    private static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        HorrorMicClient.onLogout();
    }

    private static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        try {
            HorrorMicClient.tick();
        } catch (Throwable t) {
            HorrorMicMod.LOGGER.error("Horror Mic: erro no tick (ignorado).", t);
        }
    }

    /** Indicador no canto da tela: voce sempre sabe quando o microfone esta ligado. */
    private static void onRenderGui(RenderGuiEvent.Post event) {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.options.hideGui || HorrorMicClient.state == HorrorMicClient.State.OFF) {
                return;
            }
            GuiGraphics g = event.getGuiGraphics();
            int x = g.guiWidth() - 52;

            int dot;
            String label;
            switch (HorrorMicClient.state) {
                case LISTENING -> { dot = 0xFFFF3030; label = "MIC"; }
                case LOADING -> { dot = 0xFFFFCC30; label = "MIC..."; }
                default -> { dot = 0xFF909090; label = "MIC (erro)"; }
            }
            g.fill(x, 8, x + 5, 13, dot);
            g.drawString(mc.font, label, x + 9, 6, 0xFFFFFF);

            if (HorrorMicConfig.showHeard() && !HorrorMicClient.lastHeard.isEmpty()) {
                g.drawString(mc.font, HorrorMicClient.lastHeard, 6, g.guiHeight() - 12, 0xA0A0A0);
            }
        } catch (Throwable t) {
            // desenhar o indicador nunca pode derrubar o jogo
        }
    }
}

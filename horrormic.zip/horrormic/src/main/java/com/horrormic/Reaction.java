package com.horrormic;

/** Tipos de aparicao do bicho. */
public enum Reaction {
    /** Aparece longe, nas suas costas, e te encara. Some quando voce olha de volta. */
    PEEK,
    /** Aparece colado nas suas costas por 2 segundos e some. */
    BEHIND,
    /** Aparece de novo, na sua frente, e vem andando ate voce. */
    AGAIN
}

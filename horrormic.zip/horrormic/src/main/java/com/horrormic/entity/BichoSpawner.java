package com.horrormic.entity;

import com.horrormic.HorrorMicMod;
import com.horrormic.Reaction;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Cria o bicho perto de um jogador. Roda no servidor (no singleplayer, o servidor integrado). */
public final class BichoSpawner {
    private BichoSpawner() {}

    public static void trigger(ServerPlayer player, Reaction reaction) {
        try {
            ServerLevel level = player.serverLevel();

            // So um bicho por vez.
            level.getEntitiesOfClass(BichoEntity.class, player.getBoundingBox().inflate(160.0D))
                    .forEach(Entity::discard);

            Vec3 pos = switch (reaction) {
                case PEEK -> findSpot(level, player, 14.0D, 22.0D, 180.0D, 70.0D);
                case BEHIND -> findSpot(level, player, 2.5D, 3.5D, 180.0D, 25.0D);
                case AGAIN -> findSpot(level, player, 8.0D, 12.0D, 0.0D, 50.0D);
            };
            if (pos == null) {
                return; // sem lugar para ficar em pe: simplesmente nao aparece
            }

            BichoEntity bicho = HorrorMicMod.BICHO.get().create(level);
            if (bicho == null) {
                return;
            }
            bicho.moveTo(pos.x, pos.y, pos.z, 0.0F, 0.0F);
            bicho.lookAt(EntityAnchorArgument.Anchor.EYES, player.getEyePosition());
            bicho.yBodyRot = bicho.getYRot();
            bicho.setReaction(reaction);
            level.addFreshEntity(bicho);

            switch (reaction) {
                case PEEK -> level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.WARDEN_HEARTBEAT, SoundSource.AMBIENT, 1.6F, 0.8F);
                case BEHIND -> {
                    level.playSound(null, pos.x, pos.y, pos.z,
                            SoundEvents.ENDERMAN_SCREAM, SoundSource.HOSTILE, 1.2F, 0.5F);
                    player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 40, 0, false, false));
                }
                case AGAIN -> {
                    level.playSound(null, pos.x, pos.y, pos.z,
                            SoundEvents.ENDERMAN_STARE, SoundSource.HOSTILE, 1.5F, 0.5F);
                    level.playSound(null, player.getX(), player.getY(), player.getZ(),
                            SoundEvents.WARDEN_HEARTBEAT, SoundSource.AMBIENT, 1.6F, 0.7F);
                }
            }
        } catch (Throwable t) {
            HorrorMicMod.LOGGER.error("Horror Mic: falha ao invocar o bicho (ignorada).", t);
        }
    }

    /**
     * Procura um lugar onde o bicho caiba em pe.
     *
     * @param centerDeg direcao em graus relativa para onde o jogador olha (0 = frente, 180 = costas)
     * @param spreadDeg variacao aleatoria em graus
     */
    private static Vec3 findSpot(ServerLevel level, ServerPlayer p, double minD, double maxD,
                                 double centerDeg, double spreadDeg) {
        RandomSource rnd = level.random;
        Vec3 look = p.getLookAngle();
        double baseYaw = Math.atan2(look.z, look.x);

        for (int i = 0; i < 28; i++) {
            double ang = baseYaw + Math.toRadians(centerDeg + (rnd.nextDouble() * 2.0D - 1.0D) * spreadDeg);
            double d = minD + rnd.nextDouble() * (maxD - minD);
            double x = p.getX() + Math.cos(ang) * d;
            double z = p.getZ() + Math.sin(ang) * d;

            if (!level.hasChunkAt(BlockPos.containing(x, p.getY(), z))) {
                continue;
            }
            for (int dy = 3; dy >= -4; dy--) {
                BlockPos feet = BlockPos.containing(x, p.getY() + dy, z);
                if (canStand(level, feet)) {
                    return new Vec3(feet.getX() + 0.5D, feet.getY(), feet.getZ() + 0.5D);
                }
            }
        }
        return null;
    }

    private static boolean canStand(ServerLevel level, BlockPos feet) {
        BlockPos below = feet.below();
        return level.getBlockState(feet).getCollisionShape(level, feet).isEmpty()
                && level.getBlockState(feet.above()).getCollisionShape(level, feet.above()).isEmpty()
                && level.getBlockState(feet.above(2)).getCollisionShape(level, feet.above(2)).isEmpty()
                && level.getFluidState(feet).isEmpty()
                && level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
    }
}

package com.horrormic.entity;

import com.horrormic.HorrorMicMod;
import com.horrormic.Reaction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * O bicho. Nao causa dano, nao pode ser ferido e nunca e salvo no mundo.
 * Ele so assusta: aparece, encara e some.
 */
public class BichoEntity extends PathfinderMob {
    private Reaction reaction = Reaction.PEEK;
    private int life;
    private int stareTicks;
    private int holdTicks;

    public BichoEntity(EntityType<? extends BichoEntity> type, Level level) {
        super(type, level);
        this.setInvulnerable(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.23D)
                .add(Attributes.FOLLOW_RANGE, 64.0D);
    }

    public void setReaction(Reaction reaction) {
        this.reaction = reaction;
    }

    @Override
    public boolean shouldBeSaved() {
        return false; // nunca fica gravado no mundo
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    private int maxLife() {
        return switch (reaction) {
            case PEEK -> 20 * 14;
            case BEHIND -> 50;
            case AGAIN -> 20 * 10;
        };
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        try {
            serverTick();
        } catch (Throwable t) {
            // Qualquer falha aqui so remove o bicho. O jogo e o jogador nao sao afetados.
            HorrorMicMod.LOGGER.error("Horror Mic: o bicho falhou e foi removido.", t);
            this.discard();
        }
    }

    private void serverTick() {
        life++;
        Player player = this.level().getNearestPlayer(this, 128.0D);
        if (player == null || life > maxLife()) {
            vanish();
            return;
        }

        this.getLookControl().setLookAt(player, 90.0F, 90.0F);

        switch (reaction) {
            case PEEK -> {
                this.getNavigation().stop();
                if (isBeingWatched(player)) {
                    stareTicks++;
                } else if (stareTicks > 0) {
                    stareTicks--;
                }
                if (stareTicks >= 28) { // ~1,4 s sendo encarado
                    vanish();
                }
            }
            case BEHIND -> this.getNavigation().stop();
            case AGAIN -> {
                if (this.distanceTo(player) > 3.0F) {
                    if (life % 5 == 0) {
                        this.getNavigation().moveTo(player, 1.0D);
                    }
                } else {
                    this.getNavigation().stop();
                    if (++holdTicks > 16) {
                        jolt(player);
                        vanish();
                    }
                }
            }
        }
    }

    private boolean isBeingWatched(Player player) {
        Vec3 view = player.getViewVector(1.0F).normalize();
        Vec3 toMe = new Vec3(
                this.getX() - player.getX(),
                this.getEyeY() - player.getEyeY(),
                this.getZ() - player.getZ()).normalize();
        return view.dot(toMe) > 0.96D && player.hasLineOfSight(this);
    }

    /** Susto final: grito e um escurecimento rapido. Sem dano. */
    private void jolt(Player player) {
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                SoundEvents.ENDERMAN_SCREAM, SoundSource.HOSTILE, 1.0F, 0.6F);
        if (player instanceof ServerPlayer sp) {
            sp.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 50, 0, false, false));
        }
    }

    private void vanish() {
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.LARGE_SMOKE,
                    this.getX(), this.getY() + 1.0D, this.getZ(),
                    25, 0.3D, 0.9D, 0.3D, 0.01D);
        }
        this.discard();
    }
}

package com.horrormic.entity;

import com.horrormic.HorrorMicMod;
import com.horrormic.Reaction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * O bicho. Aparece, fica visivel por 1 segundo (20 ticks) e desaparece.
 * Nao causa dano, nao pode ser ferido, nao anda e nunca e salvo no mundo.
 */
public class BichoEntity extends PathfinderMob {
    /** Quanto tempo ele fica visivel, em ticks (20 ticks = 1 segundo). */
    public static final int VISIBLE_TICKS = 20;

    private Reaction reaction = Reaction.PEEK;
    private int life;

    public BichoEntity(EntityType<? extends BichoEntity> type, Level level) {
        super(type, level);
        this.setInvulnerable(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.FOLLOW_RANGE, 64.0D);
    }

    public void setReaction(Reaction reaction) {
        this.reaction = reaction;
    }

    @Override
    public boolean shouldBeSaved() {
        return false; // nunca fica gravado no mundo
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        try {
            life++;
            Player player = this.level().getNearestPlayer(this, 128.0D);
            if (player == null || life >= VISIBLE_TICKS) {
                vanish();
                return;
            }
            this.getNavigation().stop();
            this.getLookControl().setLookAt(player, 90.0F, 90.0F);
        } catch (Throwable t) {
            // Qualquer falha aqui so remove o bicho. O jogo e o jogador nao sao afetados.
            HorrorMicMod.LOGGER.error("Horror Mic: o bicho falhou e foi removido.", t);
            this.discard();
        }
    }

    private void vanish() {
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.LARGE_SMOKE,
                    this.getX(), this.getY() + 1.0D, this.getZ(),
                    25, 0.3D, 0.9D, 0.3D, 0.01D);
        }
        this.discard();
    }
}

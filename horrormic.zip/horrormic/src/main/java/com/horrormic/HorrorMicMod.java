package com.horrormic;

import com.horrormic.client.ClientSetup;
import com.horrormic.entity.BichoEntity;
import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import org.slf4j.Logger;

@Mod(HorrorMicMod.MODID)
public class HorrorMicMod {
    public static final String MODID = "horrormic";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<BichoEntity>> BICHO =
            ENTITIES.register("bicho", () -> EntityType.Builder
                    .of(BichoEntity::new, MobCategory.MISC)
                    .sized(0.6F, 2.1F)
                    .clientTrackingRange(10)
                    .build("bicho"));

    public HorrorMicMod(IEventBus modBus) {
        ENTITIES.register(modBus);
        modBus.addListener(this::onAttributes);

        // Tudo que toca em microfone / tela / renderizacao fica em classes so de cliente.
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientSetup.init(modBus);
        }
    }

    private void onAttributes(EntityAttributeCreationEvent event) {
        event.put(BICHO.get(), BichoEntity.createAttributes().build());
    }
}

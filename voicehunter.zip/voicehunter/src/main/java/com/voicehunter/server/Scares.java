package com.voicehunter.server;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

/**
 * Plays sounds ONLY to one player (nobody else hears them), at an arbitrary position.
 * This is what makes the "was that real?" scares work: a whisper right behind you that your
 * friends on the same server cannot hear.
 */
public final class Scares {

    public static void playTo(ServerPlayer player, SoundEvent sound, SoundSource source,
                              double x, double y, double z, float volume, float pitch) {
        if (player.connection == null) {
            return;
        }
        Holder<SoundEvent> holder = BuiltInRegistries.SOUND_EVENT.wrapAsHolder(sound);
        player.connection.send(new ClientboundSoundPacket(holder, source, x, y, z, volume, pitch,
                player.getRandom().nextLong()));
    }

    /** Sound coming from {@code dist} blocks directly behind where the player is looking. */
    public static void playBehind(ServerPlayer player, SoundEvent sound, double dist, float volume, float pitch) {
        Vec3 look = player.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        if (flat.lengthSqr() < 1.0E-4) {
            flat = new Vec3(0, 0, 1);
        }
        flat = flat.normalize();
        playTo(player, sound, SoundSource.AMBIENT,
                player.getX() - flat.x * dist, player.getEyeY() - 0.4, player.getZ() - flat.z * dist, volume, pitch);
    }

    /** Sound at a random direction {@code dist} blocks away. */
    public static void playAround(ServerPlayer player, SoundEvent sound, double dist, float volume, float pitch) {
        double angle = player.getRandom().nextDouble() * Math.PI * 2.0;
        playTo(player, sound, SoundSource.AMBIENT,
                player.getX() + Math.cos(angle) * dist, player.getY() + 1.0, player.getZ() + Math.sin(angle) * dist,
                volume, pitch);
    }

    private Scares() {
    }
}

package com.voicehunter.client;

import com.voicehunter.entity.HunterState;
import com.voicehunter.entity.Reaction;
import com.voicehunter.network.HunterFeedbackPayload;
import com.voicehunter.voice.Intent;

/**
 * Entry points called from the network layer. Kept apart from {@code ModNetwork} so that a dedicated
 * server never loads client classes.
 */
public final class ClientHooks {

    public static void onFeedback(HunterFeedbackPayload payload) {
        ClientState.setFeedback(
                Reaction.byId(payload.reaction()),
                Intent.byOrdinal(payload.intent()),
                payload.state() < 0 ? null : HunterState.byId(payload.state()),
                payload.distance());
    }

    private ClientHooks() {
    }
}

package com.voicehunter.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.voicehunter.VoiceHunterMod;
import com.voicehunter.entity.HunterState;
import com.voicehunter.entity.VoiceHunterEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** A tall, thin figure (about 2.9 blocks) with arms that reach almost to its knees. */
public class HunterModel extends EntityModel<VoiceHunterEntity> {

    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(VoiceHunterMod.MODID, "voice_hunter"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public HunterModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = body.getChild("head");
        this.rightArm = body.getChild("right_arm");
        this.leftArm = body.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    /** Texture sheet is 64x64; see assets/voicehunter/textures/entity/voice_hunter.png */
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // pivot at the hip (y = 6 px above the feet line at 24)
        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 20).addBox(-3.0F, -20.0F, -2.0F, 6.0F, 20.0F, 4.0F),
                PartPose.offset(0.0F, 6.0F, 0.0F));
        body.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -9.0F, -4.0F, 8.0F, 9.0F, 8.0F),
                PartPose.offset(0.0F, -20.0F, 0.0F));
        body.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(32, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 24.0F, 2.0F),
                PartPose.offset(-4.0F, -19.0F, 0.0F));
        body.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(40, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 24.0F, 2.0F),
                PartPose.offset(4.0F, -19.0F, 0.0F));
        root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(48, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 18.0F, 2.0F),
                PartPose.offset(-1.5F, 6.0F, 0.0F));
        root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(56, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 18.0F, 2.0F),
                PartPose.offset(1.5F, 6.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(VoiceHunterEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        HunterState state = entity.getHunterState();

        // reset
        body.xRot = 0f;
        head.zRot = 0f;
        head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        head.xRot = headPitch * ((float) Math.PI / 180F);

        float swing = limbSwingAmount;
        rightLeg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.1F * swing;
        leftLeg.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.1F * swing;
        rightArm.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * 0.7F * swing;
        leftArm.xRot = Mth.cos(limbSwing * 0.6662F) * 0.7F * swing;
        rightArm.zRot = 0.04F;
        leftArm.zRot = -0.04F;

        float sway = Mth.sin(ageInTicks * 0.05F) * 0.03F;

        switch (state) {
            case HUNTING, RUNNING -> {
                // arms reaching forward, head low
                rightArm.xRot = -1.45F + Mth.sin(ageInTicks * 0.6F) * 0.1F;
                leftArm.xRot = -1.45F - Mth.sin(ageInTicks * 0.6F) * 0.1F;
                body.xRot = 0.25F;
                head.xRot += 0.2F;
            }
            case SLEEPING -> {
                // slumped, head down, limp arms
                body.xRot = 0.55F;
                head.xRot = 0.85F;
                head.yRot = 0f;
                rightArm.xRot = 0.35F + sway;
                leftArm.xRot = 0.35F - sway;
            }
            case FROZEN -> {
                // a statue: no sway at all
                rightArm.xRot = 0.05F;
                leftArm.xRot = 0.05F;
            }
            case WATCHING, STALKING -> {
                head.zRot = 0.16F; // uncomfortably tilted head
                rightArm.zRot += sway;
                leftArm.zRot -= sway;
            }
            default -> {
                rightArm.zRot += sway;
                leftArm.zRot -= sway;
            }
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buffer, int light, int overlay,
                               float r, float g, float b, float a) {
        root.render(pose, buffer, light, overlay, r, g, b, a);
    }
}

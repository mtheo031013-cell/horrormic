package com.voicehunter.client.voice;

/**
 * Minimal view of a streaming speech recogniser. It only uses JDK types so that the rest of the mod
 * never touches the Vosk classes directly: if the native library cannot be loaded, only
 * {@link VoskBackend} fails and the game keeps running.
 */
public interface SpeechRecognizer extends AutoCloseable {

    /**
     * Feeds 16 kHz, 16-bit, mono, little-endian PCM audio.
     *
     * @return {@code true} when the speaker stopped talking and a final result is available
     */
    boolean accept(byte[] pcm, int length);

    /** Final text for the utterance that just ended (JSON as produced by the engine). */
    String result();

    /** Text of the utterance in progress (JSON as produced by the engine). */
    String partial();

    @Override
    void close();
}

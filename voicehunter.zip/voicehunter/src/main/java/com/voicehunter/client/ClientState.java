package com.voicehunter.client;

import com.voicehunter.entity.HunterState;
import com.voicehunter.entity.Reaction;
import com.voicehunter.voice.Intent;

import javax.annotation.Nullable;

/** Everything the HUD shows. Written by the voice thread / network handler, read by the render thread. */
public final class ClientState {

    // --- what the microphone heard ---
    public static volatile String lastPhrase = "";
    public static volatile long lastPhraseTime;
    public static volatile String partial = "";
    /** Smoothed input volume 0..1, drives the level bar. */
    public static volatile float micLevel;

    // --- how the monster answered (server -> client) ---
    @Nullable
    public static volatile Reaction reaction;
    @Nullable
    public static volatile Intent understood;
    @Nullable
    public static volatile HunterState feedbackState;
    public static volatile float distance = -1f;
    public static volatile long feedbackTime;

    public static void setPhrase(String text) {
        lastPhrase = text;
        lastPhraseTime = System.currentTimeMillis();
        partial = "";
    }

    public static void setFeedback(Reaction r, @Nullable Intent i, @Nullable HunterState s, float dist) {
        reaction = r;
        understood = i;
        feedbackState = s;
        distance = dist;
        feedbackTime = System.currentTimeMillis();
    }

    public static void reset() {
        lastPhrase = "";
        partial = "";
        micLevel = 0f;
        reaction = null;
        understood = null;
        feedbackState = null;
        distance = -1f;
        lastPhraseTime = 0L;
        feedbackTime = 0L;
    }

    private ClientState() {
    }
}

package com.voicehunter.client.voice;

import com.sun.jna.NativeLibrary;
import com.voicehunter.VoiceHunterMod;
import org.vosk.LibVosk;
import org.vosk.LogLevel;
import org.vosk.Model;
import org.vosk.Recognizer;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Locale;

/**
 * Offline speech recognition with Vosk (Kaldi). Everything runs on the player's computer.
 * <p>
 * The Vosk jar is merged into the mod jar, together with its native libraries for Windows, Linux and macOS.
 * Before the first use the native library for this OS is copied into {@code <game>/voicehunter/natives}
 * and JNA is told to look there, which is more reliable than letting JNA find it inside a modded class loader.
 */
final class VoskBackend implements SpeechRecognizer {

    private static Model cachedModel;
    private static Path cachedModelPath;
    private static boolean nativesPrepared;

    private final Recognizer recognizer;

    private VoskBackend(Recognizer recognizer) {
        this.recognizer = recognizer;
    }

    static synchronized SpeechRecognizer create(Path modelDir, float sampleRate) throws IOException {
        prepareNatives(ModelManager.nativesDir());
        LibVosk.setLogLevel(LogLevel.WARNINGS);
        if (cachedModel == null || !modelDir.equals(cachedModelPath)) {
            if (cachedModel != null) {
                cachedModel.close();
            }
            cachedModel = new Model(modelDir.toString());
            cachedModelPath = modelDir;
        }
        return new VoskBackend(new Recognizer(cachedModel, sampleRate));
    }

    @Override
    public boolean accept(byte[] pcm, int length) {
        return recognizer.acceptWaveForm(pcm, length);
    }

    @Override
    public String result() {
        return recognizer.getResult();
    }

    @Override
    public String partial() {
        return recognizer.getPartialResult();
    }

    @Override
    public void close() {
        recognizer.close();
    }

    // ------------------------------------------------------------------------------------------

    private static void prepareNatives(Path dir) {
        if (nativesPrepared) {
            return;
        }
        nativesPrepared = true;
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        String arch = System.getProperty("os.arch", "").toLowerCase(Locale.ROOT);
        List<String> folders;
        List<String> files;
        if (os.contains("win")) {
            folders = List.of("win32-x86-64");
            files = List.of("libgcc_s_seh-1.dll", "libstdc++-6.dll", "libwinpthread-1.dll", "libvosk.dll");
        } else if (os.contains("mac") || os.contains("darwin")) {
            folders = List.of("darwin", "darwin-x86-64", "darwin-aarch64");
            files = List.of("libvosk.dylib");
        } else {
            folders = arch.contains("aarch64") || arch.contains("arm64")
                    ? List.of("linux-aarch64") : List.of("linux-x86-64");
            files = List.of("libvosk.so");
        }
        boolean any = false;
        try {
            Files.createDirectories(dir);
            for (String folder : folders) {
                for (String name : files) {
                    try (InputStream in = openResource(folder + "/" + name)) {
                        if (in != null) {
                            Files.copy(in, dir.resolve(name), StandardCopyOption.REPLACE_EXISTING);
                            any = true;
                        }
                    }
                }
            }
        } catch (IOException | RuntimeException e) {
            VoiceHunterMod.LOGGER.warn("Could not unpack the Vosk native library, JNA will try on its own", e);
        }
        if (any) {
            String path = dir.toAbsolutePath().toString();
            String old = System.getProperty("jna.library.path");
            System.setProperty("jna.library.path",
                    old == null || old.isEmpty() ? path : path + File.pathSeparator + old);
            NativeLibrary.addSearchPath("vosk", path);
            NativeLibrary.addSearchPath("libvosk", path);
            VoiceHunterMod.LOGGER.info("Vosk native library unpacked to {}", path);
        }
    }

    private static InputStream openResource(String name) {
        InputStream in = VoskBackend.class.getResourceAsStream("/" + name);
        if (in == null) {
            ClassLoader ctx = Thread.currentThread().getContextClassLoader();
            if (ctx != null) {
                in = ctx.getResourceAsStream(name);
            }
        }
        if (in == null) {
            ClassLoader own = VoskBackend.class.getClassLoader();
            if (own != null) {
                in = own.getResourceAsStream(name);
            }
        }
        return in;
    }
}

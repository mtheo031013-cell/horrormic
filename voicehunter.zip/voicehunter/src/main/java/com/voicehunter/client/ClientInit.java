package com.voicehunter.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.CommandDispatcher;
import com.voicehunter.VoiceHunterMod;
import com.voicehunter.client.voice.VoiceEngine;
import com.voicehunter.config.ClientConfig;
import com.voicehunter.registry.ModEntities;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.client.event.RegisterGuiOverlaysEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.TickEvent;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Everything that only exists on the client. Loaded from {@code VoiceHunterMod} only when running on a client. */
public final class ClientInit {

    /** Configurable in Options > Controls > "The Voice Hunter". */
    public static final KeyMapping TOGGLE_MIC = new KeyMapping("key.voicehunter.toggle_mic",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.voicehunter");

    public static void init(IEventBus modBus) {
        modBus.addListener(ClientInit::onKeys);
        modBus.addListener(ClientInit::onOverlays);
        modBus.addListener(ClientInit::onLayers);
        modBus.addListener(ClientInit::onRenderers);

        IEventBus bus = NeoForge.EVENT_BUS;
        bus.addListener(ClientInit::onClientTick);
        bus.addListener(ClientInit::onClientCommands);
        bus.addListener(ClientInit::onLogin);
        bus.addListener(ClientInit::onLogout);
        bus.addListener(ClientFx::onCamera);
        bus.addListener(ClientFx::onFog);
        bus.addListener(ClientFx::onFogColor);
    }

    private static void onKeys(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE_MIC);
    }

    private static void onOverlays(RegisterGuiOverlaysEvent event) {
        event.registerBelowAll(new ResourceLocation(VoiceHunterMod.MODID, "fx"), ClientFx::renderOverlay);
        event.registerAboveAll(new ResourceLocation(VoiceHunterMod.MODID, "hud"), VoiceHud::render);
    }

    private static void onLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(HunterModel.LAYER, HunterModel::createBodyLayer);
    }

    private static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.VOICE_HUNTER.get(), HunterRenderer::new);
    }

    private static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        while (TOGGLE_MIC.consumeClick()) {
            VoiceEngine.INSTANCE.toggle();
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                mc.player.displayClientMessage(Component.translatable(VoiceEngine.INSTANCE.isActive()
                        ? "message.voicehunter.mic_on" : "message.voicehunter.mic_off"), true);
            }
        }
        ClientFx.tick();
    }

    private static void onLogin(ClientPlayerNetworkEvent.LoggingIn event) {
        ClientState.reset();
        ClientFx.reset();
        if (ClientConfig.AUTO_START.get()) {
            VoiceEngine.INSTANCE.start();
        }
    }

    private static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        VoiceEngine.INSTANCE.stop(); // never keep the microphone open outside a world
        ClientState.reset();
        ClientFx.reset();
    }

    // ---- /voicemic ---------------------------------------------------------------------------

    private static void onClientCommands(RegisterClientCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        d.register(Commands.literal("voicemic")
                .then(Commands.literal("list").executes(ctx -> {
                    List<String> mics = VoiceEngine.listMicrophones();
                    if (mics.isEmpty()) {
                        ctx.getSource().sendFailure(Component.translatable("command.voicemic.none"));
                        return 0;
                    }
                    ctx.getSource().sendSuccess(() -> Component.translatable("command.voicemic.list"), false);
                    for (String name : mics) {
                        ctx.getSource().sendSuccess(() -> Component.literal(" - " + name), false);
                    }
                    return mics.size();
                }))
                .then(Commands.literal("use").then(Commands.argument("name", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            String name = StringArgumentType.getString(ctx, "name");
                            ClientConfig.MICROPHONE.set(name);
                            ClientConfig.MICROPHONE.save();
                            restart();
                            ctx.getSource().sendSuccess(() -> Component.translatable("command.voicemic.using", name), false);
                            return 1;
                        })))
                .then(Commands.literal("default").executes(ctx -> {
                    ClientConfig.MICROPHONE.set("");
                    ClientConfig.MICROPHONE.save();
                    restart();
                    ctx.getSource().sendSuccess(() -> Component.translatable("command.voicemic.default"), false);
                    return 1;
                }))
                .then(Commands.literal("restart").executes(ctx -> {
                    restart();
                    return 1;
                })));
    }

    private static void restart() {
        boolean wasActive = VoiceEngine.INSTANCE.isActive();
        VoiceEngine.INSTANCE.stop();
        if (wasActive) {
            VoiceEngine.INSTANCE.start();
        }
    }

    private ClientInit() {
    }
}

package com.voicehunter.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.voicehunter.VoiceHunterMod;
import com.voicehunter.entity.VoiceHunterEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

public class HunterRenderer extends MobRenderer<VoiceHunterEntity, HunterModel> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(VoiceHunterMod.MODID, "textures/entity/voice_hunter.png");
    private static final ResourceLocation EYES =
            new ResourceLocation(VoiceHunterMod.MODID, "textures/entity/voice_hunter_eyes.png");

    public HunterRenderer(EntityRendererProvider.Context context) {
        super(context, new HunterModel(context.bakeLayer(HunterModel.LAYER)), 0.4F);
        this.addLayer(new GlowLayer(this));
    }

    @Override
    public ResourceLocation getTextureLocation(VoiceHunterEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(VoiceHunterEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        if (entity.isVanished()) {
            return; // gone: nothing to draw
        }
        super.render(entity, yaw, partialTick, pose, buffer, light);
    }

    /** Glowing red eyes and mouth. Hidden while the monster sleeps. */
    private static final class GlowLayer extends EyesLayer<VoiceHunterEntity, HunterModel> {
        GlowLayer(RenderLayerParent<VoiceHunterEntity, HunterModel> parent) {
            super(parent);
        }

        @Override
        public RenderType renderType() {
            return RenderType.eyes(EYES);
        }

        @Override
        public void render(PoseStack pose, MultiBufferSource buffer, int light, VoiceHunterEntity entity,
                           float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                           float netHeadYaw, float headPitch) {
            if (entity.getHunterState() == com.voicehunter.entity.HunterState.SLEEPING) {
                return;
            }
            super.render(pose, buffer, light, entity, limbSwing, limbSwingAmount, partialTick, ageInTicks,
                    netHeadYaw, headPitch);
        }
    }
}

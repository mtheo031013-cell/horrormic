package com.voicehunter.registry;

import com.voicehunter.VoiceHunterMod;
import com.voicehunter.block.HunterBoxBlock;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(Registries.BLOCK, VoiceHunterMod.MODID);

    public static final DeferredHolder<Block, HunterBoxBlock> HUNTER_BOX = BLOCKS.register("hunter_box", () ->
            new HunterBoxBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_ORANGE)
                    .strength(0.4F)
                    .sound(SoundType.WOOL)
                    .noOcclusion()));

    private ModBlocks() {
    }
}

package com.voicehunter.entity;

import com.voicehunter.config.CommonConfig;
import com.voicehunter.registry.ModSounds;
import com.voicehunter.server.Scares;
import com.voicehunter.server.SpawnHelper;
import com.voicehunter.voice.Intent;
import com.voicehunter.voice.IntentParser;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.InteractionHand;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.UUID;

/**
 * The Voice Hunter.
 * <p>
 * A tall, silent thing that lives off the player's voice. The client recognises speech locally and the
 * server calls {@link #hear} with the result. What the monster does with it depends on its
 * {@link HunterPersonality}: it may obey, ignore, mishear, or pretend to obey and betray you later.
 * <p>
 * Besides reacting to speech, the monster has its own will: it watches from far away, stalks while you
 * are not looking, vanishes and reappears behind you.
 */
public class VoiceHunterEntity extends Monster {

    private static final EntityDataAccessor<Integer> DATA_STATE =
            SynchedEntityData.defineId(VoiceHunterEntity.class, EntityDataSerializers.INT);

    /** Where a vanished monster will show up again. */
    private enum Reappear {
        RANDOM, WATCH, STALK_BEHIND, SCARE_BEHIND
    }

    public final HunterPersonality personality = new HunterPersonality();

    // ---- server side brain state ----
    private HunterState state = HunterState.IDLE;
    private HunterState previousState = HunterState.IDLE;
    private int stateTicks;
    private int stateDuration = -1;          // -1 = until something changes it
    private int idleWait = 120;
    @Nullable
    private UUID targetId;
    @Nullable
    private Vec3 lastHeardPos;
    @Nullable
    private Vec3 searchTarget;
    private int vanishTicks;
    private Reappear reappearPlan = Reappear.RANDOM;
    private int attackCooldown;
    private int staredTicks;
    private int seenTicks;
    private int arrivedTicks;
    private boolean closeDecisionMade;
    private int lonelyTicks;
    private boolean fakeSleeping;
    private long betrayAt = -1;              // game tick at which a faked obedience turns into betrayal

    public VoiceHunterEntity(EntityType<? extends VoiceHunterEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
        this.setPersistenceRequired();
        if (!level.isClientSide) {
            personality.randomize(this.random);
        }
        if (getNavigation() instanceof GroundPathNavigation nav) {
            nav.setCanOpenDoors(true);
            nav.setCanPassDoors(true);
            nav.setCanFloat(true);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 60.0)
                .add(Attributes.MOVEMENT_SPEED, 0.27)
                .add(Attributes.ATTACK_DAMAGE, 6.0)
                .add(Attributes.FOLLOW_RANGE, 64.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6)
                .add(Attributes.ARMOR, 4.0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new OpenDoorGoal(this, true));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_STATE, HunterState.IDLE.ordinal());
    }

    // ------------------------------------------------------------------------------------------
    //  state access
    // ------------------------------------------------------------------------------------------

    /** Safe to call on both sides: the state is synced to clients (renderer, HUD, effects). */
    public HunterState getHunterState() {
        return HunterState.byId(this.entityData.get(DATA_STATE));
    }

    public boolean isVanished() {
        return getHunterState() == HunterState.VANISHED;
    }

    public void bindTo(ServerPlayer player) {
        this.targetId = player.getUUID();
    }

    @Nullable
    public UUID getTargetId() {
        return targetId;
    }

    /** Server only. */
    public void setState(HunterState newState, int duration) {
        if (level().isClientSide) {
            return;
        }
        if (newState != state) {
            previousState = state;
        }
        state = newState;
        stateTicks = 0;
        stateDuration = duration;
        arrivedTicks = 0;
        seenTicks = 0;
        staredTicks = 0;
        closeDecisionMade = false;
        if (newState == HunterState.IDLE) {
            idleWait = 100 + random.nextInt(180);
        }
        if (newState != HunterState.SLEEPING) {
            fakeSleeping = false;
        }
        this.entityData.set(DATA_STATE, newState.ordinal());
    }

    // ------------------------------------------------------------------------------------------
    //  hearing: called by the server when the player speaks
    // ------------------------------------------------------------------------------------------

    /**
     * @param match    what the phrase parser found, or {@code null} when it did not resemble anything
     * @param text     what the player said (empty = only a voice / noise was detected)
     * @param loudness 0 (whisper) .. 1 (shout)
     */
    public HearResult hear(ServerPlayer player, @Nullable IntentParser.Match match, String text, float loudness) {
        if (targetId == null) {
            bindTo(player);
        }
        lastHeardPos = player.position();

        // The voice itself is a stimulus, whatever the words are: shouting angers it, whispering draws it.
        if (loudness > 0.8f) {
            personality.addAggression(0.04f);
        }

        if (text.isEmpty()) {
            reactToVoice(player, loudness);
            return new HearResult(Reaction.NOISE, null);
        }
        if (match == null) {
            reactToVoice(player, loudness);
            return new HearResult(Reaction.UNKNOWN, null);
        }

        Intent intent = IntentParser.resolveNegation(match);
        if (!intent.isCommand()) {
            reactToTone(player, intent, loudness);
            return new HearResult(Reaction.MOOD, intent);
        }

        personality.commandsHeard++;
        if (state == HunterState.SLEEPING && intent != Intent.WAKE && loudness > 0.55f) {
            wake(true); // a shouted command wakes it up, and it is not happy
        }

        // an angry monster does not take orders... except a challenge
        if (personality.aggression >= 0.7f && intent != Intent.ATTACK) {
            glare(player);
            return new HearResult(Reaction.IGNORED, intent);
        }

        HunterPersonality.Outcome outcome = personality.decide(random, match.confidence(),
                CommonConfig.DISOBEDIENCE_SCALE.get().floatValue());
        switch (outcome) {
            case IGNORE -> {
                glare(player);
                return new HearResult(Reaction.IGNORED, intent);
            }
            case MISHEAR -> {
                Intent wrong = personality.confuse(intent, random);
                execute(wrong, player);
                return new HearResult(Reaction.MISHEARD, wrong);
            }
            case PRETEND -> {
                execute(intent, player);
                // looks obedient... for now
                betrayAt = level().getGameTime() + 100 + random.nextInt(260);
                return new HearResult(Reaction.OBEYED, intent);
            }
            default -> {
                execute(intent, player);
                personality.addTrust(0.03f);
                return new HearResult(Reaction.OBEYED, intent);
            }
        }
    }

    private void reactToVoice(ServerPlayer player, float loudness) {
        if (state == HunterState.SLEEPING) {
            if (loudness > 0.55f) {
                wake(true);
            }
            return;
        }
        if (state == HunterState.VANISHED || state == HunterState.HUNTING || state == HunterState.FROZEN) {
            return;
        }
        glare(player);
        if (state == HunterState.IDLE || state == HunterState.WATCHING) {
            // whispers attract curious monsters; shouting makes them wary and angry
            if (loudness < 0.3f && personality.curiosity > 0.5f && random.nextFloat() < 0.35f) {
                setState(HunterState.STALKING, 500);
            } else if (loudness > 0.75f && random.nextFloat() < 0.3f) {
                playSound(ModSounds.HUNTER_GROWL.get(), 0.9f, 0.8f + random.nextFloat() * 0.3f);
            }
        }
    }

    private void reactToTone(ServerPlayer player, Intent tone, float loudness) {
        switch (tone) {
            case GREET -> {
                personality.addTrust(0.05f);
                float r = random.nextFloat();
                if (r < 0.5f) {
                    whisperBack(player);
                } else if (r < 0.8f) {
                    setState(HunterState.STALKING, 400);
                } else {
                    vanishFor(40 + random.nextInt(60), Reappear.STALK_BEHIND); // "oi" -> it is behind you
                }
            }
            case PRAISE -> {
                personality.addTrust(0.15f);
                personality.addAggression(-0.12f);
                if (personality.trust > 0.4f && state != HunterState.SLEEPING) {
                    setState(HunterState.FOLLOWING, 900);
                } else {
                    whisperBack(player);
                }
            }
            case INSULT -> {
                personality.addAggression(0.3f);
                personality.addTrust(-0.2f);
                if (state == HunterState.SLEEPING) {
                    wake(true);
                }
                if (personality.aggression > 0.65f) {
                    startHunt();
                } else {
                    playSound(ModSounds.HUNTER_GROWL.get(), 1.1f, 0.7f);
                    setState(HunterState.STALKING, 600);
                }
            }
            case THREAT -> {
                personality.addAggression(0.5f);
                personality.addTrust(-0.4f);
                startHunt();
            }
            case HELP -> {
                // fear is delicious
                if (state == HunterState.SLEEPING) {
                    wake(false);
                }
                if (personality.aggression > 0.3f || random.nextFloat() < 0.5f) {
                    setState(HunterState.RUNNING, 260);
                } else {
                    setState(HunterState.COMING, 400);
                }
            }
            default -> glare(player);
        }
    }

    /** Executes a command the monster believes it heard. */
    private void execute(Intent intent, ServerPlayer player) {
        betrayAt = -1;
        switch (intent) {
            case COME -> setState(HunterState.COMING, 700);
            case STOP -> setState(HunterState.FROZEN, 200);
            case RUN -> setState(HunterState.RUNNING, 260);
            case FOLLOW -> setState(HunterState.FOLLOWING, 1400);
            case GO_AWAY -> setState(HunterState.FLEEING, 500);
            case STAY -> setState(HunterState.FROZEN, -1);
            case SEARCH -> {
                searchTarget = jitter(lastHeardPos != null ? lastHeardPos : player.position(), 6.0);
                setState(HunterState.SEARCHING, 1200);
            }
            case SLEEP -> {
                setState(HunterState.SLEEPING, 1800 + random.nextInt(1800));
                fakeSleeping = personality.fakeSleeper;
            }
            case WAKE -> {
                if (state == HunterState.SLEEPING) {
                    wake(false);
                } else {
                    glare(player);
                }
            }
            case ATTACK -> {
                personality.addAggression(0.25f);
                startHunt();
            }
            default -> glare(player);
        }
    }

    // ------------------------------------------------------------------------------------------
    //  server tick: the monster's own will
    // ------------------------------------------------------------------------------------------

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (!(level() instanceof ServerLevel serverLevel)) {
            return;
        }
        stateTicks++;
        personality.tick();
        if (attackCooldown > 0) {
            attackCooldown--;
        }

        ServerPlayer player = findPlayer(serverLevel);
        if (player == null) {
            // nobody around: wait a minute, then disappear for good
            if (++lonelyTicks > 1200) {
                discard();
            }
            return;
        }
        lonelyTicks = 0;

        double dist = distanceTo(player);
        boolean seen = isSeenBy(player, 0.35);
        boolean stared = isSeenBy(player, 0.985);

        // faked obedience: betrays you the moment you look away (or after a while anyway)
        if (betrayAt >= 0 && level().getGameTime() >= betrayAt
                && (!seen || level().getGameTime() >= betrayAt + 100)) {
            betray(player);
        }

        switch (state) {
            case IDLE -> tickIdle(serverLevel, player, dist);
            case WATCHING -> tickWatching(player, dist, stared);
            case STALKING -> tickStalking(player, dist, seen);
            case COMING -> tickComing(player, dist);
            case FOLLOWING -> tickFollowing(player, dist);
            case RUNNING -> tickRunning(player, dist);
            case FLEEING -> tickFleeing(player, dist);
            case FROZEN -> tickFrozen(player, seen);
            case SEARCHING -> tickSearching(player, dist);
            case SLEEPING -> tickSleeping(player, dist);
            case HUNTING -> tickHunting(player, dist);
            case VANISHED -> tickVanished(serverLevel, player);
        }

        if (stateDuration > 0 && stateTicks >= stateDuration) {
            onStateExpired(serverLevel, player);
        }
    }

    private void tickIdle(ServerLevel sl, ServerPlayer player, double dist) {
        glare(player);
        // lazy wander
        if (stateTicks % 60 == 0 && random.nextFloat() < 0.4f) {
            Vec3 p = DefaultRandomPos.getPos(this, 8, 4);
            if (p != null) {
                getNavigation().moveTo(p.x, p.y, p.z, 0.7);
            }
        }
        if (stateTicks < idleWait) {
            return;
        }
        // decide what to do next, all by itself
        if (personality.aggression > 0.8f) {
            startHunt();
            return;
        }
        if (dist > 60) {
            setState(HunterState.STALKING, 900);
            return;
        }
        float r = random.nextFloat();
        if (r < 0.30f) {
            vanishFor(20 + random.nextInt(40), Reappear.WATCH);
        } else if (r < 0.55f) {
            setState(HunterState.STALKING, 600);
        } else if (r < 0.75f) {
            vanishFor(100 + random.nextInt(200), Reappear.RANDOM);
        } else if (r < 0.88f) {
            setState(HunterState.WATCHING, 300 + random.nextInt(300));
        } else {
            idleWait = stateTicks + 80 + random.nextInt(120); // keeps standing there, staring
        }
    }

    private void tickWatching(ServerPlayer player, double dist, boolean stared) {
        getNavigation().stop();
        glare(player);
        if (dist < 14) {
            // you came too close: it blinks away
            vanishFor(40 + random.nextInt(80), Reappear.WATCH);
            return;
        }
        if (stared) {
            if (++staredTicks > 50) {
                vanishFor(60 + random.nextInt(140), Reappear.RANDOM);
            }
        } else if (staredTicks > 0) {
            staredTicks--;
        }
    }

    private void tickStalking(ServerPlayer player, double dist, boolean seen) {
        glare(player);
        if (seen && dist > 7) {
            // freezes while you look at it, like a statue
            getNavigation().stop();
            if (++seenTicks > 220) {
                vanishFor(60 + random.nextInt(120), Reappear.STALK_BEHIND);
            }
            return;
        }
        pathTo(player.position(), 1.15);
        if (dist < 6.5 && !closeDecisionMade) {
            closeDecisionMade = true;
            if (random.nextFloat() < 0.35f + personality.aggression * 0.6f) {
                startHunt();
            } else {
                getNavigation().stop();
                whisperBack(player);
                vanishFor(30 + random.nextInt(50), Reappear.WATCH);
            }
        }
    }

    private void tickComing(ServerPlayer player, double dist) {
        glare(player);
        if (dist > 3.0) {
            pathTo(player.position(), 0.95);
            return;
        }
        getNavigation().stop();
        if (++arrivedTicks > 60) {
            if (personality.aggression > 0.5f) {
                startHunt();
            } else {
                setState(HunterState.IDLE, -1);
            }
        }
    }

    private void tickFollowing(ServerPlayer player, double dist) {
        glare(player);
        if (personality.aggression > 0.75f) {
            startHunt();
            return;
        }
        if (dist > 5.5) {
            pathTo(player.position(), dist > 14 ? 1.5 : 1.0);
        } else if (dist < 3.0) {
            getNavigation().stop();
        }
    }

    private void tickRunning(ServerPlayer player, double dist) {
        glare(player);
        if (previousState == HunterState.FLEEING) {
            Vec3 away = DefaultRandomPos.getPosAway(this, 24, 8, player.position());
            if (away != null && stateTicks % 20 == 1) {
                getNavigation().moveTo(away.x, away.y, away.z, 1.8);
            }
            return;
        }
        if (dist > 2.4) {
            pathTo(player.position(), 1.8);
        } else {
            getNavigation().stop();
            if (personality.aggression > 0.4f) {
                startHunt();
            } else {
                playSound(ModSounds.HUNTER_GROWL.get(), 0.8f, 1.1f);
                setState(HunterState.IDLE, -1);
            }
        }
    }

    private void tickFleeing(ServerPlayer player, double dist) {
        if (dist > 42) {
            onStateExpired((ServerLevel) level(), player);
            return;
        }
        if (stateTicks % 20 == 1) {
            Vec3 away = DefaultRandomPos.getPosAway(this, 28, 8, player.position());
            if (away != null) {
                getNavigation().moveTo(away.x, away.y, away.z, 1.3);
            }
        }
    }

    private void tickFrozen(ServerPlayer player, boolean seen) {
        getNavigation().stop();
        // "fica parado": a statue. It does not even turn its head.
        if (stateDuration < 0 && stateTicks > 2400 && random.nextInt(400) == 0 && !seen) {
            setState(HunterState.STALKING, 700); // it got bored of being still
        }
    }

    private void tickSearching(ServerPlayer player, double dist) {
        if (searchTarget == null) {
            searchTarget = jitter(lastHeardPos != null ? lastHeardPos : player.position(), 6.0);
        }
        // Your voice gives your position away: it always heads for where you spoke last.
        pathTo(searchTarget, 1.15);
        if (position().distanceTo(searchTarget) < 3.0) {
            Vec3 centre = lastHeardPos != null ? lastHeardPos : player.position();
            searchTarget = jitter(centre, 7.0 + random.nextInt(5));
        }
        // found you?
        if (dist < 9 && hasLineOfSight(player)) {
            getNavigation().stop();
            Scares.playTo(player, ModSounds.STING.get(), SoundSource.HOSTILE, getX(), getY(), getZ(), 1.0f, 1.0f);
            if (personality.aggression > 0.2f || random.nextFloat() < 0.6f) {
                startHunt();
            } else {
                setState(HunterState.WATCHING, 400);
            }
        }
    }

    private void tickSleeping(ServerPlayer player, double dist) {
        getNavigation().stop();
        if (stateTicks % 20 != 0) {
            return;
        }
        if (random.nextFloat() < 0.35f) {
            playSound(ModSounds.HUNTER_BREATH.get(), 0.5f, 0.6f);
        }
        if (dist < 4.0 && random.nextFloat() < 0.5f) {
            wake(true);
            return;
        }
        // the "sleeping" ones are not always asleep
        if (fakeSleeping && dist > 8 && random.nextInt(60) == 0) {
            setState(HunterState.STALKING, 800);
        }
    }

    private void tickHunting(ServerPlayer player, double dist) {
        glare(player);
        Vec3 target = player.position();
        pathTo(target, 1.5);
        if (dist < 2.5) {
            tryAttack(player, dist);
        }
        if (dist > 90) {
            vanishFor(100, Reappear.WATCH);
        }
    }

    private void tickVanished(ServerLevel sl, ServerPlayer player) {
        getNavigation().stop();
        if (--vanishTicks <= 0) {
            reappear(sl, player);
        }
    }

    private void onStateExpired(ServerLevel sl, ServerPlayer player) {
        switch (state) {
            case WATCHING -> {
                if (random.nextBoolean()) {
                    setState(HunterState.STALKING, 600);
                } else {
                    vanishFor(100 + random.nextInt(200), Reappear.RANDOM);
                }
            }
            case STALKING -> vanishFor(100 + random.nextInt(200), Reappear.RANDOM);
            case FLEEING -> {
                if (random.nextFloat() < 0.4f + personality.mischief * 0.5f) {
                    // runs away... then turns around to stare from the distance
                    getNavigation().stop();
                    setState(HunterState.WATCHING, 400 + random.nextInt(300));
                } else {
                    vanishFor(100 + random.nextInt(200), Reappear.RANDOM);
                }
            }
            case HUNTING -> {
                personality.addAggression(-0.3f);
                vanishFor(200 + random.nextInt(300), Reappear.RANDOM);
            }
            case SLEEPING -> {
                personality.addTrust(0.05f);
                setState(HunterState.IDLE, -1);
            }
            default -> setState(HunterState.IDLE, -1);
        }
    }

    // ------------------------------------------------------------------------------------------
    //  behaviours
    // ------------------------------------------------------------------------------------------

    private void startHunt() {
        if (state == HunterState.HUNTING) {
            return;
        }
        betrayAt = -1;
        setState(HunterState.HUNTING, 400 + random.nextInt(300));
        playSound(ModSounds.HUNTER_SCREECH.get(), 1.5f, 0.9f + random.nextFloat() * 0.2f);
        if (level() instanceof ServerLevel sl && targetId != null && sl.getPlayerByUUID(targetId) instanceof ServerPlayer sp) {
            Scares.playTo(sp, ModSounds.STING.get(), SoundSource.HOSTILE, sp.getX(), sp.getY(), sp.getZ(), 0.9f, 1.0f);
        }
    }

    private void tryAttack(ServerPlayer player, double dist) {
        if (attackCooldown > 0 || Math.abs(player.getY() - getY()) > 3.0) {
            return;
        }
        attackCooldown = 24;
        swing(InteractionHand.MAIN_HAND);
        if (!CommonConfig.ALLOW_AGGRESSION.get()) {
            // pure jump scare: screams in your face and is gone
            Scares.playTo(player, ModSounds.HUNTER_SCREECH.get(), SoundSource.HOSTILE,
                    getX(), getEyeY(), getZ(), 1.6f, 1.0f);
            vanishFor(80 + random.nextInt(120), Reappear.WATCH);
            return;
        }
        float damage = (float) getAttributeValue(Attributes.ATTACK_DAMAGE)
                * CommonConfig.DAMAGE_SCALE.get().floatValue();
        if (player.hurt(damageSources().mobAttack(this), damage)) {
            float yaw = getYRot() * ((float) Math.PI / 180F);
            player.knockback(0.7, Mth.sin(yaw), -Mth.cos(yaw));
            playSound(ModSounds.HUNTER_GROWL.get(), 1.0f, 0.8f + random.nextFloat() * 0.3f);
            if (random.nextFloat() < 0.25f) {
                vanishFor(60 + random.nextInt(120), Reappear.STALK_BEHIND); // hit and run
            }
        }
    }

    private void wake(boolean angry) {
        if (angry) {
            personality.addAggression(0.15f);
            playSound(ModSounds.HUNTER_GROWL.get(), 1.0f, 0.6f);
            setState(HunterState.WATCHING, 300);
        } else {
            setState(HunterState.IDLE, -1);
        }
    }

    /** Looks straight at the player and stays that way: the "it understood, but did nothing" stare. */
    private void glare(ServerPlayer player) {
        if (state != HunterState.FROZEN && state != HunterState.SLEEPING && state != HunterState.VANISHED) {
            getLookControl().setLookAt(player, 40.0f, 40.0f);
        }
    }

    private void whisperBack(ServerPlayer player) {
        // a whisper right behind the speaker; only the speaker hears it
        Scares.playBehind(player, ModSounds.HUNTER_WHISPER.get(), 1.6, 1.0f, 0.85f + random.nextFloat() * 0.3f);
    }

    private void betray(ServerPlayer player) {
        betrayAt = -1;
        personality.addTrust(-0.25f);
        float r = random.nextFloat();
        if (r < 0.55f && CommonConfig.ALLOW_AGGRESSION.get()) {
            vanishFor(30 + random.nextInt(50), Reappear.SCARE_BEHIND);
        } else if (r < 0.8f) {
            vanishFor(40 + random.nextInt(80), Reappear.STALK_BEHIND);
        } else {
            playSound(ModSounds.HUNTER_GROWL.get(), 1.0f, 0.7f);
            setState(HunterState.STALKING, 500);
        }
    }

    /** Used by the director to make the monster show itself for a moment. */
    public void triggerApparition() {
        if (state == HunterState.HUNTING || state == HunterState.SLEEPING || state == HunterState.VANISHED) {
            return;
        }
        vanishFor(5, random.nextFloat() < 0.7f ? Reappear.WATCH : Reappear.STALK_BEHIND);
    }

    // ------------------------------------------------------------------------------------------
    //  vanish / reappear
    // ------------------------------------------------------------------------------------------

    private void vanishFor(int ticks, Reappear plan) {
        if (!(level() instanceof ServerLevel sl)) {
            return;
        }
        smoke(sl);
        playSound(ModSounds.HUNTER_VANISH.get(), 0.9f, 0.9f + random.nextFloat() * 0.2f);
        getNavigation().stop();
        vanishTicks = Math.max(1, ticks);
        reappearPlan = plan;
        setState(HunterState.VANISHED, -1);
    }

    private void reappear(ServerLevel sl, ServerPlayer player) {
        Reappear plan = reappearPlan;
        if (plan == Reappear.RANDOM) {
            float r = random.nextFloat();
            plan = r < 0.45f ? Reappear.WATCH : (r < 0.80f ? Reappear.STALK_BEHIND : Reappear.SCARE_BEHIND);
            if (plan == Reappear.SCARE_BEHIND && personality.aggression < 0.15f && random.nextFloat() < 0.5f) {
                plan = Reappear.STALK_BEHIND;
            }
        }
        switch (plan) {
            case WATCH -> {
                BlockPos spot = findWatchSpot(sl, player);
                if (spot == null) {
                    vanishTicks = 60; // no good place yet, try again in 3 seconds
                    return;
                }
                placeAt(sl, spot, player);
                setState(HunterState.WATCHING, 300 + random.nextInt(300));
            }
            case STALK_BEHIND -> {
                BlockPos spot = SpawnHelper.behind(sl, player, 9.0, random);
                if (spot == null) {
                    vanishTicks = 40;
                    reappearPlan = Reappear.WATCH;
                    return;
                }
                placeAt(sl, spot, player);
                setState(HunterState.STALKING, 600);
            }
            default -> { // SCARE_BEHIND
                BlockPos spot = SpawnHelper.behind(sl, player, 4.5, random);
                if (spot == null) {
                    vanishTicks = 40;
                    reappearPlan = Reappear.STALK_BEHIND;
                    return;
                }
                placeAt(sl, spot, player);
                Scares.playTo(player, ModSounds.STING.get(), SoundSource.HOSTILE,
                        player.getX(), player.getY(), player.getZ(), 1.0f, 1.0f);
                startHunt();
                stateDuration = 160; // a short, brutal chase
            }
        }
    }

    private void placeAt(ServerLevel sl, BlockPos spot, ServerPlayer player) {
        double dx = player.getX() - (spot.getX() + 0.5);
        double dz = player.getZ() - (spot.getZ() + 0.5);
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        moveTo(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5, yaw, 0.0f);
        setYHeadRot(yaw);
        setYBodyRot(yaw);
        getNavigation().stop();
        smoke(sl);
    }

    @Nullable
    private BlockPos findWatchSpot(ServerLevel sl, ServerPlayer player) {
        BlockPos fallback = null;
        for (int i = 0; i < 8; i++) {
            BlockPos spot = SpawnHelper.findSpot(sl, player.position(), 22, 36, random);
            if (spot == null) {
                continue;
            }
            if (fallback == null) {
                fallback = spot;
            }
            Vec3 head = Vec3.atCenterOf(spot).add(0, 2.0, 0);
            ClipContext ctx = new ClipContext(player.getEyePosition(), head,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player);
            if (sl.clip(ctx).getType() == HitResult.Type.MISS) {
                return spot; // it can see you, and you can see it
            }
        }
        return fallback;
    }

    private void smoke(ServerLevel sl) {
        sl.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1.4, getZ(), 18, 0.35, 0.9, 0.35, 0.01);
    }

    // ------------------------------------------------------------------------------------------
    //  helpers
    // ------------------------------------------------------------------------------------------

    private void pathTo(Vec3 pos, double speed) {
        // re-path a few times per second, not every tick (path finding is expensive)
        if (tickCount % 8 == 0) {
            getNavigation().moveTo(pos.x, pos.y, pos.z, speed);
        }
    }

    private Vec3 jitter(Vec3 centre, double radius) {
        double a = random.nextDouble() * Math.PI * 2.0;
        double d = random.nextDouble() * radius;
        return new Vec3(centre.x + Math.cos(a) * d, centre.y, centre.z + Math.sin(a) * d);
    }

    @Nullable
    private ServerPlayer findPlayer(ServerLevel sl) {
        if (targetId != null) {
            Player p = sl.getPlayerByUUID(targetId);
            if (p instanceof ServerPlayer sp && sp.isAlive() && !sp.isSpectator()) {
                return sp;
            }
        }
        Player near = sl.getNearestPlayer(this, 96.0);
        if (near instanceof ServerPlayer sp && !sp.isSpectator()) {
            targetId = sp.getUUID();
            return sp;
        }
        return null;
    }

    /** True when {@code p} has this monster inside the cone given by {@code minDot} and nothing blocks the view. */
    private boolean isSeenBy(Player p, double minDot) {
        Vec3 look = p.getViewVector(1.0F);
        Vec3 to = new Vec3(getX() - p.getX(), getEyeY() - p.getEyeY(), getZ() - p.getZ());
        double len = to.length();
        if (len < 1.0E-4) {
            return true;
        }
        return look.dot(to.scale(1.0 / len)) > minDot && p.hasLineOfSight(this);
    }

    public float getAggression() {
        return personality.aggression;
    }

    // ------------------------------------------------------------------------------------------
    //  vanilla overrides
    // ------------------------------------------------------------------------------------------

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (isVanished() && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return false;
        }
        if (!level().isClientSide && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
                && getHealth() - amount <= 1.0f) {
            // It cannot be killed that easily: it retreats, heals, and comes back for you.
            setHealth(getMaxHealth());
            personality.addAggression(0.5f);
            if (source.getEntity() instanceof ServerPlayer sp) {
                bindTo(sp);
            }
            vanishFor(600 + random.nextInt(600), Reappear.SCARE_BEHIND);
            return false;
        }
        boolean hurt = super.hurt(source, amount);
        if (hurt && !level().isClientSide) {
            personality.addAggression(0.35f);
            personality.addTrust(-0.3f);
            if (source.getEntity() instanceof ServerPlayer sp) {
                bindTo(sp);
            }
            if (state == HunterState.SLEEPING || state == HunterState.FROZEN || random.nextFloat() < 0.7f) {
                startHunt();
            }
        }
        return hurt;
    }

    @Override
    public boolean isPickable() {
        return !isVanished() && super.isPickable();
    }

    @Override
    public boolean canBeCollidedWith() {
        return !isVanished() && super.canBeCollidedWith();
    }

    @Override
    public boolean isPushable() {
        return !isVanished() && super.isPushable();
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return false;
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return switch (getHunterState()) {
            case VANISHED -> null;
            case HUNTING -> ModSounds.HUNTER_GROWL.get();
            default -> ModSounds.HUNTER_BREATH.get();
        };
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.HUNTER_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.HUNTER_DEATH.get();
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState block) {
        if (!isVanished()) {
            playSound(ModSounds.HUNTER_STEP.get(), 0.45f, 0.8f + random.nextFloat() * 0.2f);
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        personality.save(tag);
        tag.putInt("VHState", state.ordinal());
        if (targetId != null) {
            tag.putUUID("VHTarget", targetId);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        personality.load(tag);
        if (tag.hasUUID("VHTarget")) {
            targetId = tag.getUUID("VHTarget");
        }
        HunterState saved = HunterState.byId(tag.getInt("VHState"));
        // transient states start over calmly when the world is loaded
        if (saved == HunterState.VANISHED || saved == HunterState.HUNTING || saved == HunterState.SEARCHING) {
            saved = HunterState.IDLE;
        }
        state = saved;
        this.entityData.set(DATA_STATE, saved.ordinal());
    }
}

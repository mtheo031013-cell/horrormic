package com.voicehunter.entity;

import java.util.Locale;

/** What the monster did with something the player said. Shown in the HUD ("did it understand?"). */
public enum Reaction {
    NO_MONSTER, // nobody was close enough to hear
    NOISE,      // heard a voice but no words
    UNKNOWN,    // heard words, did not understand any command
    OBEYED,     // understood and is doing it (or pretending to)
    IGNORED,    // understood but refused
    MISHEARD,   // understood something else
    MOOD;       // reacted to the tone (insult, praise, greeting, cry for help)

    public String key() {
        return name().toLowerCase(Locale.ROOT);
    }

    public static Reaction byId(int id) {
        Reaction[] all = values();
        return id >= 0 && id < all.length ? all[id] : NO_MONSTER;
    }
}

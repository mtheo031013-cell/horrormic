package com.voicehunter.entity;

import com.voicehunter.voice.Intent;

import javax.annotation.Nullable;

/** Outcome of {@link VoiceHunterEntity#hear}. {@code understood} is what the monster THINKS it heard. */
public record HearResult(Reaction reaction, @Nullable Intent understood) {
}

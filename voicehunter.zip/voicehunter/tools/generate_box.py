#!/usr/bin/env python3
"""Cardboard Hunter Box: pixel-art textures, block/item models, blockstate, recipe. Run from the project root."""
import json, os
import numpy as np
from PIL import Image
R = "src/main/resources"; A = R + "/assets/voicehunter"; D = R + "/data/voicehunter"
for d in (A + "/textures/block", A + "/models/block", A + "/models/item", A + "/blockstates", D + "/recipes"): os.makedirs(d, exist_ok=True)
rng = np.random.default_rng(7)
BASE = np.array([196, 148, 90])
def px(arr, x, y, c, n=0): arr[y, x] = [*(np.clip(np.array(c) + int(rng.integers(-n, n + 1)), 0, 255)), 255]
side = np.zeros((16, 16, 4), np.uint8); top = np.zeros((16, 16, 4), np.uint8)
for y in range(16):
    for x in range(16):
        c = BASE + (-9 if x % 2 else 0)                    # corrugated cardboard ridges
        px(side, x, y, c, 5); px(top, x, y, c, 5)
for x in range(16):                                         # flap seam on the sides
    px(side, x, 2, BASE - 45, 3); px(side, x, 3, BASE + 14, 3)
for i in range(16):                                         # darker edges
    for arr in (side, top):
        for (x, y) in ((i, 0), (i, 15), (0, i), (15, i)): arr[y, x, :3] = (arr[y, x, :3] * 0.82).astype(np.uint8)
for x in range(16): px(top, x, 7, BASE - 50, 3); px(top, x, 8, BASE - 30, 3)    # flaps meet in the middle
for y in range(16):                                         # packing tape strip across the top
    for x in range(6, 10): px(top, x, y, (222, 202, 150), 4)
for y in range(0, 16, 5): px(top, 7, y, (170, 150, 105))
Image.fromarray(side, "RGBA").save(A + "/textures/block/hunter_box_side.png")
Image.fromarray(top, "RGBA").save(A + "/textures/block/hunter_box_top.png")

face = lambda tex, uv: {"uv": uv, "texture": tex}
model = {"parent": "minecraft:block/block",
         "textures": {"particle": "voicehunter:block/hunter_box_side", "side": "voicehunter:block/hunter_box_side", "top": "voicehunter:block/hunter_box_top"},
         "elements": [{"from": [1, 0, 1], "to": [15, 11, 15], "faces": {
             "north": face("#side", [1, 5, 15, 16]), "south": face("#side", [1, 5, 15, 16]),
             "east": face("#side", [1, 5, 15, 16]), "west": face("#side", [1, 5, 15, 16]),
             "up": face("#top", [1, 1, 15, 15]), "down": face("#top", [1, 1, 15, 15])}}]}
json.dump(model, open(A + "/models/block/hunter_box.json", "w"), indent=2)
json.dump({"parent": "voicehunter:block/hunter_box"}, open(A + "/models/item/hunter_box.json", "w"), indent=2)
json.dump({"variants": {"": {"model": "voicehunter:block/hunter_box"}}}, open(A + "/blockstates/hunter_box.json", "w"), indent=2)
json.dump({"type": "minecraft:crafting_shaped", "pattern": ["PPP", "PEP", "PPP"],
           "key": {"P": {"item": "minecraft:paper"}, "E": {"item": "minecraft:spider_eye"}},
           "result": {"item": "voicehunter:hunter_box"}}, open(D + "/recipes/hunter_box.json", "w"), indent=2)

for lang, name, msg in (("pt_br", "Caixa do Caçador", "Caixa colocada na sua frente."), ("en_us", "Hunter Box", "Box placed in front of you.")):
    p = f"{A}/lang/{lang}.json"; d = json.load(open(p))
    d["block.voicehunter.hunter_box"] = name; d["command.voicehunter.box_placed"] = msg
    json.dump(d, open(p, "w"), indent=2, ensure_ascii=False)
print("box ok")
